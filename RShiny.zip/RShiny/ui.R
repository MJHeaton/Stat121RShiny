## User interface for R Shiny App


# User Interface ----------------------------------------------------------

ui <- dashboardPage(
  dashboardHeader(title = "Stat 121 Analysis Tool"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Exploratory Data Analysis", tabName = "EDA"),
      menuItem("Normal Probability Calculator", tabName="NormProb"),
      menuItem("Sampling Distribution of x-bar", tabName="SampDistOfXbar"),
      menuItem("Analysis for Means", tabName = "TestMu",
               #menuSubItem("One Mean - Z Test", tabName = "OneSampZTestMu"),
               menuSubItem("One Mean", tabName = "OneSampTTestMu"),
               menuSubItem("Two Means", tabName = "TwoSampTTestMu"),
               menuSubItem("ANOVA", tabName = "ANOVA")
      ),
      menuItem("Analysis For Proportions", tabName = "ZTestP",
               menuSubItem("One Proportion", tabName = "OneSampZTestP"),
               menuSubItem("Two Proportion", tabName = "TwoSampZTestP"),
               menuSubItem("Chi-Square", tabName = "Chi-Square")
      ),
      menuItem("Regression", tabName = "Regression")
    )
  ),
  dashboardBody(
    useShinyjs(),
    setShadow("box1"),
    tags$head(
      tags$style(HTML("hr {border-top: 1px solid #000000;}"))
    ),
    
    tabItems(
      
      # Tab 1: Basics -----------------------------------------------------------
      
      tabItem(tabName = "EDA",
              h2("Exploratory Data Analysis"),fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection ----
                       
                       box(id = "EDAbox1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("EDAData", "Select dataset: ", list.of.data.names),
                           textOutput("EDAText"),
                           br(),
                           textOutput("EDAN"),
                           hr(),
                           checkboxInput("EDAHeader",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.EDAHeader == true", tableOutput("EDATable")),
                           hr()
                       ),
                       #2 Select variables ----

                        box(id = "EDAbox2", title = "2) Select Variable", width = 12, solidHeader = TRUE, status = "primary",
                            div(id = "EDAdiv",
                                 textOutput("EDAmuVar"),
                                uiOutput("EDAExplanatory")
                            )
                        ),
                       # 
                       # # #3 Check conditions ----
                       #
                       box(
                         id = "EDAbox3", title = "3) Graphical Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         div(id = "EDAbox3div",
                             selectInput("EDAwhichPlot", "Which plot would you like to draw?",
                                         choices=c("---",
                                                   "Histogram",
                                                   "Density (smoothed histogram)",
                                                   "Boxplot",
                                                   "Dotplot",
                                                   "Barplot",
                                                   "Pie Chart"
                                         )),
                             plotOutput("EDAPlot")
                         )
                       ),
                        box(
                          id = "EDAbox3p1", title = "4) Numerical Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                          div(id = "EDAbox3p1div",
                              selectInput("EDAwhichNumSum", "Which summary would you like to calculate?",
                                          choices=c("---","Mean",
                                                    "Standard Deviation",
                                                    "Median",
                                                    "Mode",
                                                    "5 Number Summary",
                                                    "Skewness",
                                                    "Table of Counts"
                                          )),
                              verbatimTextOutput("EDANumEDA")
                          )
                        )
                )#end column
              ) #end fluidRow
              
      ),
      
      # Tab 2: Procedures for Means -----------------------------------------
      # Subtab 1: One-Sample Z Test for Means
      
      tabItem(tabName = "OneSampZTestMu",
              h2("One-Sample Z Test for Means"),
              fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection ----
                       
                       box(id = "ztestmu1box1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("ztestmu1Data", "Select dataset: ", list.of.data.names),
                           textOutput("ztestmu1Text"),
                           br(),
                           textOutput("ztestmu1N"),
                           checkboxInput("ztestmu1Header",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ztestmu1Header == true", tableOutput("ztestmu1Table")),
                           hr(),
                           actionButton("ztestmu1Button1", label = "Select This Dataset")
                       ),
                       
                       #2 Select variables ----
                       
                       box(id = "ztestmu1box2", title = "2) Select Variable", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ztestmu1box2div",
                                      # textOutput("ztestmuVar"),
                                      uiOutput("ztestmu1Explanatory"),
                                      hr(),
                                      uiOutput("ZTestQuantCheckButton")
                           ))
                       ),
                       
                       #3 Check conditions ----
                       box(
                         id = "ztestmu1box3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "ztestmu1box3div",
                                    # selectInput("ZwhichNumSum", "Which numerical summary would you like to calculate?",
                                    #             choices=c("---","Mean",
                                    #                       "Standard Deviation",
                                    #                       "Median",
                                    #                       "Mode",
                                    #                       "5 Number Summary",
                                    #                       "Table of Counts"
                                    #             )),
                                    # verbatimTextOutput("ztestmu1NumEDA"),
                                    #br(),
                                    selectInput("ZwhichPlot", "Which plot would you like to draw?",
                                                choices=c("---",
                                                          "Histogram",
                                                          "Density (smoothed histogram)",
                                                          "Boxplot",
                                                          "Dotplot",
                                                          "Barplot",
                                                          "Pie Chart"
                                                )),
                                    plotOutput("ztestmu1Plot"),
                                    br(),
                                    selectInput("ZwhichNumSum", "Which numerical summary would you like to calculate?",
                                                choices=c("---","Mean",
                                                          "Standard Deviation",
                                                          "Median",
                                                          "Mode",
                                                          "Skewness",
                                                          "5 Number Summary",
                                                          "Table of Counts"
                                                )),
                                    verbatimTextOutput("ztestmu1NumEDA"),
                                    hr(),
                                    actionButton("ztestmu1Button3", label = "Proceed to Statistical Inference")
                         ))
                       ),
                       
                       #4 Test
                       
                       box(id = "ztestmu1box4", title = "4) Performing the Test and Calculating the CI", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ztestmubox4div",
                                      numericInput("ztestmu1NullValue", "Null Value:", 0),
                                      numericInput("ztestSigValue", "Population Standard Deviation (sigma):", 1, min = 0, max = 99999999),
                                      selectInput("ztestmu1Alternative", "Which sided hypothesis do you want to use?",
                                                  choices=c("Not Equal To"="two.sided",
                                                            "<"="less",
                                                            ">"="greater")),
                                      sliderInput("ztestmu1ConfLevel", "Confidence Level:", min=0.50, max=0.99, value=0.95, step=0.01),
                                      verbatimTextOutput("ztestmu1TestOutput")
                           ))
                       )
                       
                       
                       
                ) # end column
              ) #End Fluid row
      ), ## End onesampztestmu Tab
      
      # Subtab 2 : One Sample T Test for Means
      tabItem(tabName = "OneSampTTestMu",
              h2("One-Sample T Test for Means"),
              fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection ----
                       
                       box(id = "ttestmu1box1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("ttestmu1Data", "Select dataset: ", list.of.data.names),
                           textOutput("ttestmu1Text"),
                           br(),
                           textOutput("ttestmu1N"),
                           checkboxInput("ttestmu1Header",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ttestmu1Header == true", tableOutput("ttestmu1Table")),
                           hr(),
                           actionButton("ttestmu1Button1", label = "Select This Dataset")
                       ),
                       
                       #2 Select variables ----
                       
                       box(id = "ttestmu1box2", title = "2) Select Variables", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ttestmu1div",
                                      uiOutput("ttestmu1Explanatory"),
                                      hr(),
                                      uiOutput("TTestQuantCheckButton")
                           ))
                       ),
                       #3 Check conditions ----
                       box(
                         id = "ttestmu1box3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "ttestmu1box3div",
                                    # selectInput("TwhichNumSum", "Which numerical summary would you like to calculate?",
                                    #             choices=c("---","Mean",
                                    #                       "Standard Deviation",
                                    #                       "Median",
                                    #                       "Mode",
                                    #                       "5 Number Summary",
                                    #                       "Table of Counts"
                                    #             )),
                                    # verbatimTextOutput("ttestmu1NumEDA"),
                                    #br(),
                                    selectInput("ttestmu1whichPlot", "Which plot would you like to draw?",
                                                choices=c("---",
                                                          "Histogram",
                                                          "Density (smoothed histogram)",
                                                          "Boxplot",
                                                          "Dotplot",
                                                          "Barplot",
                                                          "Pie Chart"
                                                )),
                                    plotOutput("ttestmu1Plot"),
                                    br(),
                                    selectInput("TwhichNumSum", "Which numerical summary would you like to calculate?",
                                                choices=c("---","Mean",
                                                          "Standard Deviation",
                                                          "Median",
                                                          "Mode",
                                                          "Skewness",
                                                          "5 Number Summary",
                                                          "Table of Counts"
                                                )),
                                    verbatimTextOutput("ttestmu1NumEDA"),
                                    hr(),
                                    actionButton("ttestmu1Button3", label = "Proceed to Statistical Inference")
                         ))
                       ),
                       
                       #4 Test
                       
                       box(id = "ttestmu1box4", title = "4) Performing the Test and Calculating the CI", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ttestmu1box4div", 
                                      numericInput("ttestmu1NullValue", "Null Value:", 0),
                                      selectInput("ttestmu1Alternative", "Which sided hypothesis do you want to use?",
                                                  choices=c("Not Equal To"="two.sided",
                                                            "<"="less",
                                                            ">"="greater")),
                                      sliderInput("ttestmu1ConfLevel", "Confidence Level:", min=0.50, max=0.99, value=0.95, step=0.01),
                                      verbatimTextOutput("ttestmu1TestOutput")
                           ))
                       )
                       
                       
                ) # end column
              ) #End Fluid row
      ), ## End ttestmu1 Tab
      
      # Subtab 3 : Two Sample T Test for Means
      tabItem(tabName = "TwoSampTTestMu",
              h2("Two-Sample T Test for Means"),
              fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection ----
                       
                       box(id = "ttestmu2box1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("ttestmu2Data", "Select dataset: ", list.of.data.names),
                           textOutput("ttestmu2Text"),
                           br(),
                           textOutput("ttestmu2N"),
                           checkboxInput("ttestmu2Header",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ttestmu2Header == true",tableOutput("ttestmu2Table")),
                           hr(),
                           actionButton("ttestmu2Button1", label = "Select This Dataset")
                       ),
                       
                       #2 Select variables ----
                       
                       box(id = "ttestmu2box2", title = "2) Select Variables", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ttestmu2div",
                                      uiOutput("ttestmu2samp1"), 
                                      #verbatimTextOutput("ttestmu2twoCat"),
                                      uiOutput("ttestmu2samp2"),
                                      hr(),
                                      # uiOutput("T2TestQuantCheckButton"),
                                      uiOutput("ttestmu2choosepop1"), 
                                      uiOutput("ttestmu2choosepop2"),
                                      hr(),
                                      uiOutput("T2TestQuantCheckButton")
                           )#end div ttestmu2div
                           )
                       ),
                       
                       #2B Further select population if there are more than two options
                       # box(id = "ttestmu2box2B", title = "2B) Further Select Populations", width = 12, solidHeader = TRUE, status = "primary",
                       #     hidden(div(id = "ttestmu2divB",
                       #                uiOutput("ttestmu2choosepop1"), 
                       #                uiOutput("ttestmu2choosepop2"),
                       #                hr(),
                       #                uiOutput("T2TestQuantCheckButtonB")
                       #     ))
                       # ),
                       
                       #3 Check conditions ----
                       box(
                         id = "ttestmu2box3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "ttestmu2box3div",
                                    # selectInput("T2whichNumSum", "Which numerical summary would you like to calculate for each group?",
                                    #             choices=c("---","Means",
                                    #                       "Standard Deviations",
                                    #                       "Medians",
                                    #                       "Modes",
                                    #                       "5 Number Summaries",
                                    #                       "Table of Counts",
                                    #                       "Proportions"
                                    #             )),
                                    # tableOutput("ttestmu2NumEDA"),
                                    #br(),
                                    selectInput("ttestmu2whichPlot", "Which plot would you like to draw?",
                                                choices=c("---","Histograms", "Densities (Smoothed Histograms)"="dens", "Dotplots", "Boxplots",
                                                          "Barplots",
                                                          "Pie Charts"
                                                )),
                                    plotOutput("ttestmu2Plot"),
                                    br(),
                                    selectInput("T2whichNumSum", "Which numerical summary would you like to calculate for each group?",
                                                choices=c("---","Means",
                                                          "Sample Sizes",
                                                          "Standard Deviations",
                                                          "Medians",
                                                          "Modes",
                                                          "Skewness",
                                                          "5 Number Summaries",
                                                          "Table of Counts",
                                                          "Proportions"
                                                )),
                                    tableOutput("ttestmu2NumEDA"),
                                    hr(),
                                    actionButton("ttestmu2Button3", label = "Proceed to Statistical Inference")
                         )), #end hidden and div
                         hidden(div(id = "ttestmu2box3divB",
                                    # selectInput("T2whichNumSumB", "Which numerical summary would you like to calculate for each group?",
                                    #             choices=c("---","Means",
                                    #                       "Standard Deviations",
                                    #                       "Medians",
                                    #                       "Modes",
                                    #                       "5 Number Summaries",
                                    #                       "Table of Counts",
                                    #                       "Proportions"
                                    #             )),
                                    # tableOutput("ttestmu2NumEDAB"),
                                    br(),
                                    selectInput("ttestmu2whichPlotB", "Which plot would you like to draw?",
                                                choices=c("---","Histograms", "Densities (Smoothed Histograms)"="dens", "Dotplots", "Boxplots",
                                                          "Barplots",
                                                          "Pie Charts"
                                                )),
                                    plotOutput("ttestmu2PlotB"),
                                    br(),
                                    selectInput("T2whichNumSumB", "Which numerical summary would you like to calculate for each group?",
                                                choices=c("---","Means",
                                                          "Sample Sizes",
                                                          "Standard Deviations",
                                                          "Medians",
                                                          "Modes",
                                                          "Skewness",
                                                          "5 Number Summaries",
                                                          "Table of Counts",
                                                          "Proportions"
                                                )),
                                    tableOutput("ttestmu2NumEDAB"),
                                    hr(),
                                    actionButton("ttestmu2Button3B", label = "Proceed to Statistical Inference")
                         ))
                       ),
                       
                       #4 Test
                       box(id = "ttestmu2box4", title = "4) Performing the Test", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "ttestmu2box4div",
                                      selectInput("ttestmu2Alternative", "Which sided hypothesis do you want to use?",
                                                  choices=c("Not Equal To"="two.sided",
                                                            "<"="less",
                                                            ">"="greater")),
                                      sliderInput("ttestmu2ConfLevel", "Confidence Level:", min=0.50, max=0.99, value=0.95, step=0.01),
                                      verbatimTextOutput("ttestmu2TestOutput")
                           )), #end hidden and div
                           hidden(div(id = "ttestmu2box4divB",
                                      selectInput("ttestmu2AlternativeB", "Which sided hypothesis do you want to use?",
                                                  choices=c("Not Equal To"="two.sided",
                                                            "<"="less",
                                                            ">"="greater")),
                                      sliderInput("ttestmu2ConfLevelB", "Confidence Level:", min=0.50, max=0.99, value=0.95, step=0.01),
                                      verbatimTextOutput("ttestmu2TestOutputB")
                           ))
                       )
                       
                       
                ) # end column
              ) #End Fluid row
      ), ## End ttestmu2 Tab
      
      # Tab Number Something: One Sample Z Test for Proportions -----------------------------------
      
      tabItem(tabName = "OneSampZTestP",
              h2("One-Sample Z Test for Proportions"),
              fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection -----
                       
                       box(id = "OneSampP1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("OneSampZTestPData", "Select Dataset", list.of.data.names),
                           textOutput("ZtestP1Text"),
                           br(),
                           textOutput("ZtestP1N"),
                           checkboxInput("ZtestP1header",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ZtestP1header == true",uiOutput("ZtestP1Table")),
                           hr(),
                           actionButton("ztestp1Button1", label = "Select This Dataset")
                       ),
                       
                       #2 Select Variable -----
                       
                       box(id = "OneSampP2", title = "2) Select Variable", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "OneSampP1div",
                                      uiOutput("ZtestP1Explanatory"),
                                      hr(),
                                      uiOutput("ZPTestCatCheckButton")
                           ))
                       ),
                       
                       #3 EDA ----
                       box(id = "OneSampP3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "OneSampP1div2",
                                      # selectInput("whichNumEDAP1", "Which numerical summary would you like to calculate?", 
                                      #             choices = c("---","Mean", "Standard Deviation", "Median", "Mode",
                                      #                         "5 Number Summary", "Proportions", "Table of Counts")),
                                      # tableOutput("OneSampPNumOutput"),
                                      #br(),
                                      selectInput("whichPlotP1", "Which plot would you like to see?", 
                                                  choices = c("---","Histogram", "Density (Smoothed Histogram)"="dens", "Dotplot", "Boxplot",
                                                              "Bar Chart",
                                                              "Pie Chart"
                                                  )),
                                      plotOutput("OneSampPPlot"),
                                      br(),
                                      selectInput("whichNumEDAP1", "Which numerical summary would you like to calculate?", 
                                                  choices = c("---","Mean", "Standard Deviation", "Median", "Mode",
                                                              "5 Number Summary", "Proportions", "Table of Counts")),
                                      tableOutput("OneSampPNumOutput"),
                                      hr(),
                                      actionButton("ztestp1Button3", label="Proceed to Statistical Inference")
                           ))
                       ),
                       
                       #4 The test
                       box(id = "OneSampP4", title = "4) Performing the One-Sample Z Test for Proportions", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "OneSampP1div3",
                                      uiOutput("ZPV"),
                                      numericInput("Pnull", "Null Hypothesis Proportion (must be between 0 and 1)", 0.5),
                                      selectInput("WhichHypoP1", "Choose an alternative hypothesis: ", choices = c("---", ">", "<", "not equal to")),
                                      sliderInput("OneSampPConfLevel", "Please select a confidence level", min = 0.5, max = 0.99, value = 0.95, step = 0.01),
                                      verbatimTextOutput(outputId = "OneSampP1Need")
                           ))) #end box
                       
                ) #end column
              ) #end fluidrow
      ), #end OneSampZTestP
      
      # Tab _: Two Sample z-test for Proportions ----------------------------------------------------
      tabItem(tabName = "TwoSampZTestP",
              h2("Two-Sample Z Test for Proportions"),
              fluidRow(
                column(width = 12,
                       
                       #1 Dataset Selection -----
                       
                       box(id = "TwoSampP1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("TwoSampZTestPData", "Select Dataset", list.of.data.names),
                           textOutput("ZtestP2Text"),
                           br(),
                           textOutput("ZtestP2N"),
                           checkboxInput("ZtestP2header",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ZtestP2header == true",uiOutput("ZtestP2Table")),
                           hr(),
                           actionButton("ztestp2Button1", label = "Select This Dataset")
                       ),
                       
                       #2 Select Variable -----
                       
                       box(id = "TwoSampP2", title = "2) Select Population", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "TwoSampP2div",
                                      uiOutput("ZtestP2Population"),
                                      uiOutput("ZtestP2VarName"),
                                      hr(),
                                      uiOutput("ZP2ChoosePopLevelOne"),
                                      uiOutput("ZP2ChoosePopLevelTwo"),
                                      hr(),
                                      uiOutput("ZP2TestCatCheckButton")
                                      
                           ))#,
                           # div(id="TestingTwodivs",
                           #     verbatimTextOutput("div2test"))
                       ),
                       
                       #2B Allow for selection of population when there are more than two options
                       # box(id = "TwoSampP2B", title = "2B) Further Select Population", width = 12, solidHeader = TRUE, status = "primary",
                       #     hidden(div(id = "TwoSampP2Bdiv",
                       #                uiOutput("ZP2ChoosePopLevelOne"),
                       #                uiOutput("ZP2ChoosePopLevelTwo"),
                       #                actionButton("ztestp2BButton3", label = "Proceed to EDA")
                       #     )) #end div
                       # ),
                       
                       #3 EDA
                       box(id = "TwoSampP3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "TwoSampP3div",
                                      # selectInput("whichNumEDAP2", "Which numerical summary would you like to calculate?", 
                                      #             choices = c("---", "Means", "Standard Deviations", "Medians", "Modes",
                                      #                         "5 Number Summaries", "Proportions", "Table of Counts")),
                                      # tableOutput("TwoSampPNumOutput"),
                                      #br(),
                                      selectInput("WhichPlotP2", "Which plot would you like to see?", 
                                                  choices = c("---","Histograms", "Densities (Smoothed Histograms)"="dens", "Dotplots", "Boxplots",
                                                              "Bar Charts",
                                                              "Pie Charts")),
                                      plotOutput("TwoSampPPlot"),
                                      br(),
                                      selectInput("whichNumEDAP2", "Which numerical summary would you like to calculate?", 
                                                  choices = c("---", "Means", "Standard Deviations", "Medians", "Modes",
                                                              "5 Number Summaries", "Proportions", "Table of Counts")),
                                      tableOutput("TwoSampPNumOutput"),
                                      hr(),
                                      actionButton("ztestp2Button3", label = "Proceed to Statistical Inference")
                           )), #end div and hidden
                           hidden(div(id = "TwoSampP3divB",
                               # selectInput("whichNumEDAP2B", "Which numerical summary would you like to calculate?",
                               #             choices = c("---", "Means", "Standard Deviations", "Medians", "Modes",
                               #                         "5 Number Summaries", "Proportions", "Table of Counts")),
                               # tableOutput("TwoSampPNumOutputB"),
                               #br(),
                               selectInput("WhichPlotP2B", "Which plot would you like to see?",
                                           choices = c("---","Histograms", "Densities (Smoothed Histograms)"="dens", "Dotplots", "Boxplots",
                                                       "Bar Charts",
                                                       "Pie Charts")),
                               plotOutput("TwoSampPPlotB"),
                               br(),
                               selectInput("whichNumEDAP2B", "Which numerical summary would you like to calculate?",
                                           choices = c("---", "Means", "Standard Deviations", "Medians", "Modes", "Skewness",
                                                       "5 Number Summaries", "Proportions", "Table of Counts")),
                               tableOutput("TwoSampPNumOutputB"),
                               hr(),
                               actionButton("ztestp2Button3B", label = "Proceed to Statistical Inference")
                           )) #end div id=TwoSampP3divB and end hidden
                       ), #end box
                       
                       
                       #4 The Test
                       box(id = "TwoSampP4", title = "4) Performing the Two Sample Z Test for Proportions", width = 12,
                           solidHeader = TRUE, status = "primary",
                           hidden(div(id = "TwoSampP4div",
                                      uiOutput("ZtestP2Explanatory"),
                                      selectInput("WhichHypoP2", "Choose an alternative hypothesis: P1 __ P2", choices = c("---", ">", "<", "not equal to")),
                                      sliderInput("TwoSampPConfLevel", "Select a confidence level: ", min = 0.5, max = 0.99, value = 0.95, step = 0.01),
                                      verbatimTextOutput(outputId = "TwoSampP4test")
                           )), #end div id="TwoSampP4div" and hidden
                           hidden(div(id = "TwoSampP4divB",
                                      uiOutput("ZtestP2ExplanatoryB"),
                                      selectInput("WhichHypoP2B", "Choose an alternative hypothesis: P1 __ P2", choices = c("---", ">", "<", "not equal to")),
                                      sliderInput("TwoSampPConfLevelB", "Select a confidence level: ", min = 0.5, max = 0.99, value = 0.95, step = 0.01),
                                      verbatimTextOutput(outputId = "TwoSampP4testB")
                           ))
                           ) #end box
                ) #end column
              ) #end fluid row
      ), #end TwoSampZTestP
      
      
      # Tab 2: Regression -------------------------------------------------------
      
      tabItem(tabName = "Regression", 
              h2("Regression"),
              fluidRow(
                column(width = 12, 
                       
                       #1 Dataset Selection ----
                       
                       box(id = "regbox1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("regData", "Select dataset: ", list.of.data.names),
                           textOutput("regText"),
                           br(),
                           textOutput("regN"),
                           checkboxInput("showDataHeader",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.showDataHeader == true",uiOutput("dataHeader")),
                           hr(),
                           actionButton("regButton1", label = "Select This Dataset")
                       ),
                       
                       #2 Select variables ----
                       
                       box(id = "regbox2", title = "2) Select Variables", width = 12, solidHeader = TRUE, status = "primary", 
                           hidden(div(id = "regbox2div",
                               textOutput("reg2"),
                               uiOutput("Explanatory"),
                               uiOutput("Response"),
                               hr(),
                               uiOutput("RegVarsCheckButton")
                           ))
                       ),
                       
                       
                       #3 Scatterplot ----
                       
                       box(
                         id = "regbox3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "regbox3div",
                             # selectInput("regWhichNumEDA", "Which numerical summary do you want to calculate?",
                             #             choices=c("---", "Mean of Explanatory Variable", "Mean of Response Variable",
                             #                       "Std. Dev. of Explanatory Variable", "Std. Dev. of Response Variable",
                             #                       "Median of Explanatory Variable", "Median of Response Variable",
                             #                       "Mode of Explanatory Variable", "Mode of Response Variable",
                             #                       "Correlation between Explanatory and Response Variable",
                             #                       "Covariance between Explanatory and Response Variable")),
                             # verbatimTextOutput("regNumEDA"),
                             br(),
                             selectInput("whichPlot", "Which plot would you like to draw?", 
                                         choices=c("---","Histogram of Explanatory Variable",
                                                   "Histogram of Response Variable",
                                                   "Density of Explanatory Variable",
                                                   "Density of Response Variable",
                                                   "Scatterplot")),
                             plotOutput("regPlot"),
                             br(),
                             selectInput("regWhichNumEDA", "Which numerical summary do you want to calculate?",
                                         choices=c("---", "Mean of Explanatory Variable", "Mean of Response Variable",
                                                   "Std. Dev. of Explanatory Variable", "Std. Dev. of Response Variable",
                                                   "Median of Explanatory Variable", "Median of Response Variable",
                                                   "Mode of Explanatory Variable", "Mode of Response Variable",
                                                   "Correlation between Explanatory and Response Variable",
                                                   "Covariance between Explanatory and Response Variable")),
                             verbatimTextOutput("regNumEDA"),
                             hr(),
                             actionButton("regButton3", "Proceed to Checking Assumptions")
                         ))
                       ),#,
                       
                       #4 Check Assumptions ------
                       box(
                         id = "regbox4", title = "4) Check Regression Assumptions", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "regbox4div",
                             selectInput("regAssumption", "What regression assumption plot do you want to look at?",
                                         choices=c("---",
                                                   "Scatterplot (Linearity)",
                                                   "Histogram of Residuals (Normality)",
                                                   "Fitted vs. Residuals (Equal Variance)")),
                             plotOutput("residPlot"),
                             hr(),
                             actionButton("regButton4", "Proceed to Regression Analysis (Statistical Inference)")
                         ))
                       ),
                       
                       #5 Check Assumptions ----
                       box(
                         id = "regbox5", title = "5) Regression Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "regbox5div",
                             sliderInput("betaConfLevel", "Confidence Level for Slope and Intercept:", min=0.50, max=0.99, value=0.95, step=0.01),
                             verbatimTextOutput("regCoefText"),
                             tableOutput("regCoefTable"),
                             verbatimTextOutput("regSummary"),
                             checkboxInput("showRegLine", label = "Show Fitted Regression Line"),
                             conditionalPanel("input.showRegLine == true",plotOutput("corPlot")),
                             hr(),
                             actionButton("regButton5", "Proceed to Predictions")
                         ))
                       ),
                       
                       
                       #6 Prediction ------
                       box(
                         id = "regbox6", title = "6) Prediction", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "regbox6div",
                             sliderInput("RegConfLevel", "Confidence Level for Predictions:", min=0.50, max=0.99, value=0.95, step=0.01),
                             numericInput("RegPredict", "X value for which you want to predict", 0),
                             selectInput("ConfOrPredInt", "What kind of interval do you want?",
                                         choices = c("Confidence Interval",
                                                     "Prediction Interval")),
                             verbatimTextOutput(outputId = "prediction")
                             ))
                       )
                       
                ) #End column
                
                
                
              ) #End Fluid row
      ), ## End Regression Tab
      
      
      # Tab something: ANOVA ----------------------------------------------
      tabItem(tabName = "ANOVA", 
              h2("ANOVA"),
              fluidRow(
                column(width = 12, 
                       
                       #1 Dataset Selection ----
                       
                       box(id = "anovabox1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("DataANOVA", "Select dataset: ", list.of.data.names),
                           textOutput("TextANOVA"),
                           br(),
                           textOutput("nANOVA"),
                           checkboxInput("showdataHeaderANOVA", label= "Display First 6 Rows of Dataset"),
                           conditionalPanel("input.showdataHeaderANOVA == true", uiOutput("dataHeaderANOVA")),
                           hr(),
                           actionButton("ANOVAButton1", label = "Select This Dataset")
                       ),
                       
                       #2 Variable Selection -----
                       box(id = "anovabox2", title = "2) Select Variables", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "anovadiv",
                                      uiOutput("anovagroup"), 
                                      verbatimTextOutput("ANOVAgroupLevels"),
                                      uiOutput("anovavar"),
                                      hr(),
                                      uiOutput("AnovaCheckButton")
                           ))
                       ),
                       
                       #3 Check conditions ----
                       box(
                         id = "anovabox3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "anovabox3div",
                                    # selectInput("ANOVAwhichNumSum", "Which numerical summary would you like to calculate for each group?",
                                    #             choices=c("---","Sample sizes","Means",
                                    #                       "Standard Deviations",
                                    #                       "Medians",
                                    #                       "Modes",
                                    #                       "5 Number Summaries",
                                    #                       "Table of Counts",
                                    #                       "Proportions"
                                    #             )),
                                    # tableOutput("anovaNumEDA"),
                                    br(),
                                    selectInput("anovawhichPlot", "Which plot would you like to draw?",
                                                choices=c("---","Histograms", "Densities (Smoothed Histograms)"="dens", "Dotplots", "Boxplots",
                                                          "Barplots",
                                                          "Pie Charts"
                                                )),
                                    plotOutput("anovaPlot"),
                                    br(),
                                    selectInput("ANOVAwhichNumSum", "Which numerical summary would you like to calculate for each group?",
                                                choices=c("---","Sample sizes","Means",
                                                          "Standard Deviations",
                                                          "Skewness",
                                                          "Medians",
                                                          "Modes",
                                                          "5 Number Summaries",
                                                          "Table of Counts",
                                                          "Proportions"
                                                )),
                                    tableOutput("anovaNumEDA"),
                                    hr(),
                                    actionButton("ANOVAButton3", label = "Proceed to Statistical Inference")
                         ))
                       ),
                       
                       #4 Do the test --------------
                       
                       box(id = "anovabox4", title = "4) Performing the Test", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "anovabox4div",
                                      verbatimTextOutput("anovaTest"),
                                      sliderInput("ANOVAConfLevel", "Confidence Level:", min=0.50, max=0.99, value=0.95, step=0.01),
                                  plotOutput("errorbars")))
                       )#end box
                       
                )   
              ) #End Fluid row
      ), ## End ANOVA Tab
      
      
      # Tab 3: Chi-square -------------------------------------------------------
      
      tabItem(tabName = "Chi-Square", 
              h2("Chi-square"),
              fluidRow(
                column(width = 12, 
                       
                       #1 Dataset Selection ----
                       
                       box(id = "chisqbox1",
                           title = "1) Dataset Selection", width = 12, solidHeader = TRUE, status = "primary",
                           selectInput("chisqData", "Select dataset: ", list.of.data.names),
                           textOutput("chisqText"),
                           br(),
                           textOutput("chisqN"),
                           checkboxInput("ChiSqshowDataHeader",label="Display First 6 Rows of Dataset"),
                           conditionalPanel("input.ChiSqshowDataHeader == true",uiOutput("ChiSqdataHeader")),
                           hr(),
                           actionButton("chiSqButton1", label = "Select This Dataset")
                       ),
                       
                       #2 Select Variables ----
                       
                       box(id = "chisqbox2",
                           title = "2) Select Variables", width = 12, solidHeader = TRUE, status = "primary", 
                           hidden(div(id = "chisqbox2div",
                               textOutput("Chi2text2"),
                               uiOutput("Chi2Row"),
                               #span(textOutput("ChiSqRowError"), style="color:red"),
                               uiOutput("Chi2Column"),
                               hr(),
                               uiOutput("ChiSqVarsCheckButton")
                           ))
                       ),
                       
                       #3 Exploratory Data Analysis ----
                       
                       box(
                         id = "chisqbox3", title = "3) Exploratory Data Analysis", width = 12, solidHeader = TRUE, status = "primary",
                         hidden(div(id = "chisqbox3div", 
                         #            selectInput("ChiSqNumSum", "What numerical summaries would you like to calculate?", 
                         #             choices=c("---",
                         #                       "Counts of Row Variable",
                         #                       "Counts of Column Variable",
                         #                       "Two Way Table of Counts",
                         #                       "Conditional Distribution of Column given Row",
                         #                       "Conditional Distribution of Row given Column")),
                         # tableOutput("ChiSqNumEDA"),
                         selectInput("ChiSqwhichPlot", "What graphical summaries would you like to display?",
                                     choices=c("---",
                                               "Barplot of Row Variable",
                                               "Barplot of Column Variable",
                                               "Piechart of Row Variable",
                                               "Piechart of Column Variable")), 
                         plotOutput("ChiSqPlotEDA"),
                         br(),
                         selectInput("ChiSqNumSum", "What numerical summaries would you like to calculate?", 
                                     choices=c("---",
                                               "Counts of Row Variable",
                                               "Counts of Column Variable",
                                               "Two Way Table of Counts",
                                               "Conditional Distribution of Column given Row",
                                               "Conditional Distribution of Row given Column")),
                         tableOutput("ChiSqNumEDA"),
                         hr(),
                         actionButton("chiSqButton3", label = "Proceed to Statistical Inference")
                         ))
                       ),
                       
                       #4 Performing the Test ----
                       
                       box(id = "chisqbox4",
                           title = "4) Chi-square Test", width = 12, solidHeader = TRUE, status = "primary",
                           hidden(div(id = "chisqbox4div",
                           verbatimTextOutput("ChiSqTestText"),
                           verbatimTextOutput("ChiSqEVText"),
                           tableOutput("ExpectedCounts"),
                           verbatimTextOutput("ChiSqCompText"),
                           tableOutput("ChiSqComponents"),
                           verbatimTextOutput("ChiSqTest")
                           ))
                       )
                       
                )  #End column
              ) ## End fluid row
      ), ## End Chi-square Tab
      
      #Tab Four: Normal Probability Calculator -------------------------------------------
      tabItem(tabName = "NormProb",
              h2("Normal Probability Calculator"),
              fluidRow(
                column(width = 12,
                       box(id = "Zbox1",
                           title = "Probabilities from Normal Distribution", width = 12, solidHeader = TRUE, status = "primary",
                           div(id = "Zdiv1",
                               selectInput("Tail", "Which tail?", choices = c("Lower Tail", "Upper Tail", "Between")),
                               numericInput("NormProbMean", "What is the mean of the normal distribution?", 0),
                               numericInput("NormProbStd", "What is the standard deviation of the normal distribution?", 1),
                               numericInput("Zscore", "What is the value?", 0),
                               conditionalPanel(condition = "input.Tail=='Between'", 
                                                numericInput("Zscore2", "What is the second value?", 2)),
                               verbatimTextOutput(outputId = "Zprob"),
                               plotOutput("NormalAreaShaded")
                           )), #end div and box
                       
                       
                       box(id = "Zbox2",
                           title = "Percentiles from Normal Distribution", width = 12, solidHeader = TRUE, status = "primary",
                           div(id = "Zdiv1",
                               selectInput("PctTail", "Which tail?", choices = c("Lower Tail", "Upper Tail", "Between")),
                               numericInput("NormPctMean", "What is the mean of the normal distribution?", 0),
                               numericInput("NormPctStd", "What is the standard deviation of the normal distribution?", 1),
                               numericInput("Normprob", "What percentile (must be between 0 and 1)?", 0.5),
                               conditionalPanel(condition = "input.PctTail=='Between'", 
                                                numericInput("Normprob2", "What is the second percentile (must be between 0 and 1)?",0.95)),
                               verbatimTextOutput(outputId = "NormPct"),
                               plotOutput("NormalPctAreaShaded")
                           )) #end div and box
                ) #End column
              ) #end fluid row
              
      ), #End Normal Probability Calculator tab
      
      #Tab Five Sampling Distribution of Xbar --------------------------------------------
      tabItem(tabName = "SampDistOfXbar",
              h2("Sampling Distribution of x-bar"),
              fluidRow(
                column(width = 12,
                       box(id = "Zbox1",
                           title = "", width = 12, solidHeader = TRUE, status = "primary",
                           div(id = "SampDistXbar", 
                               radioButtons("dist", "Population Distribution type:",
                                            c("Normal" = "norm",
                                              "Uniform" = "unif",
                                              "Left Skewed" = "beta",
                                              "Right Skewed" = "gamma")),
                               sliderInput("n", 
                                           label="Sample size:", 
                                           value = 100,
                                           min = 1, 
                                           max = 200,
                                           ticks=FALSE),
                               plotOutput("SampDistplot"),
                               br(),
                               br(),
                               br(),
                               br(),
                               br(),
                               br(),
                               br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br()
                           ))#end div and box
                ) #end column
              ) #end fluid row
      ) #end Sampling Distribution Tab
      
      #Tab For Google Form --------------------------------------------
      # tabItem(tabName = "Google Form",
      #         h2("Google Form"),
      #         fluidRow(
      #           column(width = 12,
      #                  box(id = "GoogleForm",
      #                      title = "Survey For Next Class", width = 12, solidHeader = TRUE, status = "primary",
      #                      div(id = "Survey", 
      #                          tags$iframe(id = "googleform",
      #                                      src = "https://docs.google.com/forms/d/e/1FAIpQLSevrkGR0zJwRMvcJbme_9MIpHZaBAVs_6wjDT6DsUDUXtbhfQ/viewform?usp=pp_url",
      #                                      width = 400,
      #                                      height = 600,
      #                                      frameborder = 0,
      #                                      marginheight = 0)
      #                      )
      #                  )
      #           )
      #         ) #end fluid row
      # ) #end Google Form Tab 
    )
  )
)

