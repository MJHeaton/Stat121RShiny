# Setup -------------------------------------------------------------------

# server ------------------------------------------------------------------

server <- function(input, output) {
  
  # Tab 1 -------------------------------------------------------------------
  
  output$EDAText <- renderText({
    paste("Description:",data.desc[[which(input$EDAData==list.of.data.names)]])
  })
  
  EDAdataSet <- reactive({
    which.set <- which(input$EDAData == list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$EDATable <- renderTable({
    head(EDAdataSet())
  })
  
  output$EDAN <- renderText({
    paste("Sample size:", nrow(EDAdataSet()))
  })
  
  output$EDAHeader <- renderUI({
    tableOutput("EDATable")
  })
  
  output$EDAExplanatory <- renderUI({
    varNames0 <- names(EDAdataSet())
    selectInput("selectV0",
                label="Please select the variable you wish to explore:",
                choices=varNames0)
  })
  
  output$EDANumEDA <- renderPrint({
    switch(input$EDAwhichNumSum,
           "Mean"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"Mean cannot be calculated for categorical data"}
                  else{cat(paste("Mean =", round(mean(EDAdataSet()[[input$selectV0]], na.rm=TRUE),2)))},
           "Skewness"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"Skewness cannot be calculated for categorical data"}
                  else{cat(paste("Skewness =", round(moments::skewness(EDAdataSet()[[input$selectV0]], na.rm=TRUE),2)))},
           "Standard Deviation"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"Standard Deviation cannot be calculated for categorical data"}
                                else{cat(paste("SD =", round(sd(EDAdataSet()[[input$selectV0]], na.rm=TRUE),2)))},
           "Median"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"Median cannot be calculated for categorical data"}
                    else{cat(paste("Median =", round(median(EDAdataSet()[[input$selectV0]], na.rm=TRUE),2)))},
           "Mode"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"Mode cannot be calculated for categorical data"}
           else{cat(paste("(Approximate) Mode =", round(density(EDAdataSet()[[input$selectV0]], na.rm=TRUE)$x[which.max(density(EDAdataSet()[[input$selectV0]], na.rm=TRUE)$y)],2)))},
           "5 Number Summary" = if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){"5 Number Summary cannot be calculated for categorical data"}
           else{cat(paste(c("Min=","Q1=","Q2=","Q3=","Max="),round(quantile(EDAdataSet()[[input$selectV0]], na.rm=TRUE),2), collapse="; "))},
           "Table of Counts" = if(class(EDAdataSet()[[input$selectV0]]) != "character" & class(EDAdataSet()[[input$selectV0]]) != "factor"){"Table of Counts cannot be calculated for quantitative data"}
           else{{
             myedatab <- as.data.frame(addmargins(table(EDAdataSet()[[input$selectV0]], useNA="no")))
             names(myedatab) <- c("Category", "Count")
             myedatab
           }},
           "Proportions"= {
             myedatab <- as.data.frame(round(prop.table(table(EDAdataSet()[[input$selectV0]], useNA="no")), digits=3))
             names(myedatab) <- c("Category", "Proportion")
             myedatab
           },
           "---"=cat(" "))
  })
  
  
  output$EDAPlot <- renderPlot({
    switch(input$EDAwhichPlot,
           "Histogram"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Histograms are not appropriate for categorical data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())
             } else {
               ggplot(EDAdataSet(),aes_string(x=input$selectV0))+geom_histogram(col="gray")
             },
           "Dotplot"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Dot Plots are not appropriate for categorical data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())}
             else{
               
               ggplot(EDAdataSet(),aes_string(x=input$selectV0))+geom_dotplot(col="gray", dotsize = .5) + scale_y_continuous(NULL, breaks = NULL)
               },
           "Boxplot"=if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Boxplots are not appropriate for categorical data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())
             } else {
               ggplot(EDAdataSet(), aes_string(y=input$selectV0)) + geom_boxplot() + theme(axis.text.x=element_blank())
             },
           "Density (smoothed histogram)"= if(class(EDAdataSet()[[input$selectV0]]) == "character" | class(EDAdataSet()[[input$selectV0]]) == "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Density plots are not appropriate for categorical data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())
             } else {
               ggplot(EDAdataSet(), aes_string(x=input$selectV0))+geom_density(size=1.5)
             },
           "Pie Chart" = if(class(EDAdataSet()[[input$selectV0]]) != "character" & class(EDAdataSet()[[input$selectV0]]) != "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie charts are not appropriate for quantitative data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())
             } else {
               with(EDAdataSet()[!is.na(EDAdataSet()[[input$selectV0]]),],{
                 pie(table(get(input$selectV0)),
                     col=rainbow(length(unique(get(input$selectV0)))),
                     labels = paste(levels(get(input$selectV0)),
                                    paste0(round(table(get(input$selectV0))/sum(table(get(input$selectV0))),3)*100,"%")))})
               },
           "Barplot" = if(class(EDAdataSet()[[input$selectV0]]) != "character" & class(EDAdataSet()[[input$selectV0]]) != "factor"){
             ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
               xlab("") + ylab("") + theme(axis.text = element_blank())
           } else {
               ggplot(EDAdataSet()[!is.na(EDAdataSet()[[input$selectV0]]),], aes_string(x = input$selectV0)) + geom_bar()
            }
    ) #End Switch
  }) #End Renderplot
  
  
  
  
  # One-Sample Z Test for Means -------------------------------------------------
  # Step 1 (select dataset)-------------------------------------------
  
  output$ztestmu1Text <- renderText({
    paste("Description:",data.desc[[which(input$ztestmu1Data==list.of.data.names)]])
  })
  
  ZdataSet <- reactive({
    hide("ztestmu1box2div")
    hide("ztestmu1box3div")
    hide("ztestmubox4div")
    which.set <- which(input$ztestmu1Data == list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$ztestmu1Table <- renderTable({
    head(ZdataSet())
  })
  
  output$ztestmu1N <- renderText({
    paste("Sample size:", nrow(ZdataSet()))
  })
  
  output$ztestmu1Header <- renderUI({
    tableOutput("ztestmu1Table")
  })
  
  observeEvent(input$ztestmu1Button1, {
    showElement(id = "ztestmu1box2div")
  })
  
  
  # One-Sample Z Test for Means Step 2 (select exp. var.)---------------------------
  output$ztestmu1Explanatory <- renderUI({
    varNames <- names(ZdataSet())
    selectInput("selectV",
                label="Please select the variable you wish to test (MUST be quantitative):",
                choices=varNames)
  })
  
  output$ZTestQuantError <- renderText(paste("<font color=\"#FF0000\">","Error: The variable you have selected is NOT quantitative and, hence, not approporiate
                                       for one sample z-tests.  Please select a quantitative (numeric) variable.", "</font>"))
  
  output$ZTestQuantCheckButton <- renderUI({
    if(is.numeric(ZdataSet()[[input$selectV]])){
      actionButton("ztestmu1Button2", label = "Proceed to EDA")
    } else {
      hide("ztestmu1box3div")
      hide("ztestmubox4div")
      htmlOutput("ZTestQuantError")
    }
  })
  
  observeEvent(input$ztestmu1Button2, {
    showElement(id = "ztestmu1box3div")
  })
  
  # Step 3 (EDA)
  output$ztestmu1NumEDA <- renderPrint({
    switch(input$ZwhichNumSum,
           "Mean"=cat(paste("Mean =", round(mean(ZdataSet()[[input$selectV]], na.rm=TRUE),2))),
           "Skewness"=cat(paste("Skewness =", round(moments::skewness(ZdataSet()[[input$selectV]], na.rm=TRUE),2))),
           "Standard Deviation"=cat(paste("SD =", round(sd(ZdataSet()[[input$selectV]], na.rm=TRUE),2))),
           "Median"=cat(paste("Median =", round(median(ZdataSet()[[input$selectV]], na.rm=TRUE),2))),
           "Mode"=cat(paste("(Approximate) Mode =", round(density(ZdataSet()[[input$selectV]], na.rm=TRUE)$x[which.max(density(ZdataSet()[[input$selectV]], na.rm=TRUE)$y)],2))),
           "5 Number Summary" = cat(paste(c("Min=","Q1=","Q2=","Q3=","Max="),round(quantile(ZdataSet()[[input$selectV]], na.rm=TRUE),2), collapse="; ")),
           "Table of Counts" = cat("Tables are not appropriate for quantitative data"),
           "Proportions"=data.frame(Msg="Proportions are not appropriate for quantitative data."),
           "---"=cat(" "))
  })
  
  output$ztestmu1Plot <- renderPlot({
    switch(input$ZwhichPlot,
           "Histogram"=ggplot(ZdataSet(),aes_string(x=input$selectV))+geom_histogram(col="gray"),
           "Dotplot"=ggplot(ZdataSet(),aes_string(x=input$selectV))+geom_dotplot(col="gray"),
           "Boxplot"=ggplot(ZdataSet(),aes_string(y=input$selectV)) + geom_boxplot() + theme(axis.text.x=element_blank()),
           "Density (smoothed histogram)"=ggplot(ZdataSet(),aes_string(x=input$selectV))+geom_density(size=1.5),
           "Barplot" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Pie Chart" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie Charts are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---"=ggplot()+geom_blank())
  })
  
  observeEvent(input$ztestmu1Button3, {
    showElement(id = "ztestmubox4div")
  })
  
  # Step 4 (Test)
  output$ztestmu1TestOutput <- renderPrint({
    myZtest <- ZTest(x=ZdataSet()[[input$selectV]],
                     alternative = input$ztestmu1Alternative, 
                     mu = input$ztestmu1NullValue,
                     sd_pop = input$ztestSigValue,
                     conf.level=input$ztestmu1ConfLevel)
    myCI <- ZTest(x=ZdataSet()[[input$selectV]],
                  alternative = "two.sided", 
                  mu = input$ztestmu1NullValue,
                  sd_pop = input$ztestSigValue,
                  conf.level=input$ztestmu1ConfLevel)$conf.int
    cat("Z Test for H0: Mean(", input$selectV,") =", input$ztestmu1NullValue,
        "\n",
        "Alternative Hypothesis =", myZtest$alternative,
        "\n",
        "x-bar = ", myZtest$estimate,
        "\n",
        "Pop. SD (sigma) =", input$ztestSigValue,
        "\n",
        "Z Test statistic =", myZtest$statistic, 
        "\n", 
        "p-value = ", myZtest$p.value,
        "\n",
        paste0(input$ztestmu1ConfLevel*100, "%"), "Conf. Int.:", myCI)
  })
  
  
  # One Sample T Test for Means --------------------------------
  # Step 1 : Select Dataset
  
  output$ttestmu1Text <- renderText({
    paste("Description:",data.desc[[which(input$ttestmu1Data==list.of.data.names)]])
  })
  
  ttestmu1dataSet <- reactive({
    hide("ttestmu1div")
    hide("ttestmu1box3div")
    hide("ttestmu1box4div")
    which.set <- which(input$ttestmu1Data == list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$ttestmu1Table <- renderTable({
    head(ttestmu1dataSet())
  })
  
  output$ttestmu1N <- renderText({
    paste("Sample size:", nrow(ttestmu1dataSet()))
  })
  
  output$ttestmu1Header <- renderUI({
    tableOutput("ttestmu1Table")
  })
  
  observeEvent(input$ttestmu1Button1, {
    showElement(id = "ttestmu1div")
  })
  
  
  # Step 2 (select exp. var.)---------------------------
  
  output$ttestmu1Explanatory <- renderUI({
    varNames1 <- names(ttestmu1dataSet())
    selectInput("selectV1",
                label="Please select the variable you wish to test (MUST be quantitative):",
                choices=varNames1)
  })
  
  output$TTestQuantError <- renderText(paste("<font color=\"#FF0000\">","Error: The variable you have selected is NOT quantitative and, hence, not approporiate
                                       for one sample t-tests.  Please select a quantitative (numeric) variable.", "</font>"))
  
  output$TTestQuantCheckButton <- renderUI({
    if(is.numeric(ttestmu1dataSet()[[input$selectV1]])){
      actionButton("ttestmu1Button2", label = "Proceed to EDA")
    } else {
      hide("ttestmu1box3div")
      hide("ttestmu1box4div")
      htmlOutput("TTestQuantError")
    }
  })
  
  observeEvent(input$ttestmu1Button2, {
    showElement(id = "ttestmu1box3div")
  })
  
  # Step 3 (EDA)
  output$ttestmu1NumEDA <- renderPrint({
    switch(input$TwhichNumSum,
           "Mean"=cat(paste("Mean =", round(mean(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE),2))),
           "Skewness"=cat(paste("Skewness =", round(moments::skewness(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE),2))),
           "Standard Deviation"=cat(paste("SD =", round(sd(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE),2))),
           "Median"=cat(paste("Median =", round(median(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE),2))),
           "Mode"=cat(paste("(Approximate) Mode =", round(density(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE)$x[which.max(density(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE)$y)],2))),
           "5 Number Summary" = cat(paste(c("Min=","Q1=","Q2=","Q3=","Max="),round(quantile(ttestmu1dataSet()[[input$selectV1]], na.rm=TRUE),2), collapse="; ")),
           "Table of Counts" = cat("Tables are not appropriate for quantitative data"),
           "Proportions"=data.frame(Msg="Proportions are not appropriate for quantitative data."),
           "---"=cat(" "))
  })
  
  output$ttestmu1Plot <- renderPlot({
    switch(input$ttestmu1whichPlot,
           "Histogram"=ggplot(ttestmu1dataSet(),aes_string(x=input$selectV1))+geom_histogram(col="gray"),
           "Dotplot"=ggplot(ttestmu1dataSet(),aes_string(x=input$selectV1))+geom_dotplot(col="gray"),
           "Boxplot"=ggplot(ttestmu1dataSet(),aes_string(y=input$selectV1)) + geom_boxplot() + theme(axis.text.x=element_blank()),
           "Density (smoothed histogram)"=ggplot(ttestmu1dataSet(),aes_string(x=input$selectV1))+geom_density(size=1.5),
           "Barplot" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Pie Chart" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie Charts are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---"=ggplot()+geom_blank())
  })
  
  observeEvent(input$ttestmu1Button3, {
    showElement(id = "ttestmu1box4div")
  })
  
  # Step 4 (Test)
  output$ttestmu1TestOutput <- renderPrint({
    myTtest <- t.test(x=ttestmu1dataSet()[[input$selectV1]],
                      alternative=input$ttestmu1Alternative, 
                      mu=input$ttestmu1NullValue,
                      conf.level=input$ttestmu1ConfLevel)
    myTCI <- t.test(x=ttestmu1dataSet()[[input$selectV1]],
                    alternative="two.sided", 
                    mu=input$ttestmu1NullValue,
                    conf.level=input$ttestmu1ConfLevel)$conf.int
    cat("t Test for H0: Mean(", input$selectV1,") = ", input$ttestmu1NullValue,
        "\n",
        "Alternative Hypothesis = ", input$ttestmu1Alternative,
        "\n",
        "x-bar = ", myTtest$estimate,
        "\n",
        "t Test statistic =", myTtest$statistic, 
        "\n", 
        "p-value = ", myTtest$p.value,
        "\n",
        paste0(input$ttestmu1ConfLevel*100, "%"), "Conf. Int.: ", myTCI)
  })
  
  # Two Sample T Test for Means --------------------------------
  # Step 1 : Select Dataset
  
  output$ttestmu2Text <- renderText({
    paste("Description:",data.desc[[which(input$ttestmu2Data==list.of.data.names)]])
  })
  
  ttestmu2dataSet <- reactive({
    hide("ttestmu2div")
    hide("ttestmu2box3div")
    hide("ttestmu2box4div")
    hide("ttestmu2box4divB")
    hide("ttestmu2box3divB")
    which.set <- which(input$ttestmu2Data == list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$ttestmu2Table <- renderTable({
    head(ttestmu2dataSet())
  })
  
  output$ttestmu2N <- renderText({
    paste("Sample size:", nrow(ttestmu2dataSet()))
  })
  
  output$ttestmu2Header <- renderUI({
    tableOutput("ttestmu2Table")
  })
  
  observeEvent(input$ttestmu2Button1, {
    showElement(id = "ttestmu2div")
  })
  
  # Step 2 (select samp1 and samp2 var.)---------------------------
  
  output$ttestmu2samp1 <- renderUI({
    varNames2 <- names(ttestmu2dataSet())
    selectInput("selectV2a",
                label="Please select the categorical variable that distinguishes the two groups:",
                choices=varNames2)
  })
  
  output$ttestmu2samp2 <- renderUI({
    varNames2y <- names(ttestmu2dataSet())
    varNames2y <- varNames2y[varNames2y != input$selectV2a]
    selectInput("selectV2b",
                label="Please select the quantitative variable you wish to test:",
                choices=varNames2y)
  })
  
  output$T2TestQuantError <- renderText(paste("<font color=\"#FF0000\">","Error: The variable you have selected is not quantitative and/or the levels are not catetgorical, hence, not approporiate
                                       for two sample t-tests.  Please select a quantitative (numeric) variable and categorical levels.", "</font>"))
  
  output$T2TestQuantCheckButton <- renderUI({
    if(is.numeric(ttestmu2dataSet()[[input$selectV2b]]) & !is.numeric(ttestmu2dataSet()[[input$selectV2a]]) & nlevels(ttestmu2dataSet()[[input$selectV2a]]) >= 2){
      actionButton("ttestmu2GoToEDA", label = "Proceed to EDA")
    } else {
      hide("ttestmu2box3div")
      hide("ttestmu2box4div")
      htmlOutput("T2TestQuantError")
    }
  })
  
  observeEvent(input$ttestmu2Button2, {
    showElement(id = "ttestmu2box3div")
  })
  
  observeEvent(input$ttestmu2Button2B, {
    showElement(id = "ttestmu2divB")
  })
  
  # output$ttestmu2twoCat <- renderPrint({
  #   if(nlevels(ttestmu2dataSet()[[input$selectV2a]])!=2){
  #     cat("Number of groups (levels) in",input$selectV2a,"is not 2.  Please select a different categorical variable to distinguishes the TWO groups")
  #   } else {
  #     cat("Group labels:",levels(ttestmu2dataSet()[[input$selectV2a]]))
  #   }
  # })
  
  # Step 2B: Further select population if there are more than two options
  output$ttestmu2choosepop1 <- renderUI({
    if(is.numeric(ttestmu2dataSet()[[input$selectV2b]]) & !is.numeric(ttestmu2dataSet()[[input$selectV2a]]) & nlevels(ttestmu2dataSet()[[input$selectV2a]]) >= 2){
      ttestmu2poplevels <- levels(ttestmu2dataSet()[[input$selectV2a]])
      selectInput("ttestmu2pop1", label = 'Which level would you like to be "Group 1"?', choices = ttestmu2poplevels)
    }
    # ttestmu2poplevels <- unique(ttestmu2dataSet()[[input$selectV2a]])
    # selectInput("ttestmu2pop1", label = "Please select a population level", choices = ttestmu2poplevels)
  })
  
  output$ttestmu2choosepop2 <- renderUI({
    if(is.numeric(ttestmu2dataSet()[[input$selectV2b]]) & !is.numeric(ttestmu2dataSet()[[input$selectV2a]]) & nlevels(ttestmu2dataSet()[[input$selectV2a]]) >= 2){
      ttestmu2poplevels <- levels(ttestmu2dataSet()[[input$selectV2a]])
      ttestmu2poplevels <- ttestmu2poplevels[ttestmu2poplevels != input$ttestmu2pop1]
      selectInput("ttestmu2pop2", label = 'Which level would you like to be "Group 2"?', choices = ttestmu2poplevels)
    }
    # ttestmu2poplevels <- unique(ttestmu2dataSet()[[input$selectV2a]])
    # ttestmu2poplevels <- ttestmu2poplevels[ttestmu2poplevels != input$ttestmu2pop1]
    # selectInput("ttestmu2pop2", label = "Please select a population level", choices = ttestmu2poplevels)
  })
  
  output$T2TestQuantCheckButtonB <- renderUI({
    actionButton("ttestmu2GoToEDA", "Proceed to EDA")
  })
  
  observeEvent(input$ttestmu2GoToEDA, {
    showElement(id = "ttestmu2box3divB") 
  })
  
  ttestmu2dataSet2 <- reactive({
    temporary <- ttestmu2dataSet()
    temporary %>%
      dplyr::select(input$selectV2a, input$selectV2b) %>%
      dplyr::filter(temporary[,input$selectV2a] == input$ttestmu2pop1 | temporary[,input$selectV2a] == input$ttestmu2pop2) %>%
      droplevels() 
  })
  
  # Step 3 (EDA)
  output$ttestmu2NumEDA <- renderTable({
    switch(input$T2whichNumSum,
           "Means"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=mean)
             names(my2TTab) <- c(input$selectV2a, paste0("Mean(",input$selectV2b,")"))
             my2TTab
           },
           "Sample Sizes"={
             my2TTab <- table(ttestmu2dataSet()[[input$selectV2a]])
             my2TTab
           },
           "Skewness"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=moments::skewness)
             names(my2TTab) <- c(input$selectV2a, paste0("Skewness(",input$selectV2b,")"))
             my2TTab
           },
           "Standard Deviations"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=sd)
             names(my2TTab) <- c(input$selectV2a, paste0("SD(",input$selectV2b,")"))
             my2TTab
           },
           "Medians"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=median)
             names(my2TTab) <- c(input$selectV2a, paste0("Median(",input$selectV2b,")"))
             my2TTab
           },
           "Modes"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=getNumMode)
             names(my2TTab) <- c(input$selectV2a, paste0("Approx. Mode(",input$selectV2b,")"))
             my2TTab
           },
           "5 Number Summaries" = {
             my2TTab <- as.data.frame(aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(), FUN=quantile)[,-1])
             my2TTab[[input$selectV2a]] <- levels(ttestmu2dataSet()[[input$selectV2a]])
             my2TTab <- my2TTab[,c(ncol(my2TTab),1:(ncol(my2TTab)-1))]
             names(my2TTab) <- c(input$selectV2a, "Min",paste0("Q",1:3), "Max")
             my2TTab
           },
           "Table of Counts" =data.frame(Msg="Tables not appropriate for quantitative data."),
           "Proportions"=data.frame(Msg="Proportions are not appropriate for quantitative data."),
           "---"=cat(" "))
  })
  
  output$ttestmu2Plot <- renderPlot({
    switch(input$ttestmu2whichPlot,
           "Histograms"= ggplot(ttestmu2dataSet()[!is.na(ttestmu2dataSet()[[input$selectV2a]]),], aes_string(x=input$selectV2b, fill=input$selectV2a)) +
             geom_histogram(binwidth=0.5, alpha=0.5),
           "Dotplots"=ggplot(ttestmu2dataSet()[!is.na(ttestmu2dataSet()[[input$selectV2a]]),], 
                             aes_string(x=input$selectV2b, fill=input$selectV2a))+geom_dotplot(alpha=0.5),
           "Boxplots"=ggplot(ttestmu2dataSet()[!is.na(ttestmu2dataSet()[[input$selectV2a]]),], 
                             aes_string(y=input$selectV2b, x=input$selectV2a)) +
             geom_boxplot(),
           "dens"=ggplot(ttestmu2dataSet()[!is.na(ttestmu2dataSet()[[input$selectV2a]]),], aes_string(x=input$selectV2b, color=input$selectV2a)) +
             geom_density(),
           "Barplots" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Pie Charts" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie Charts are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---"=ggplot()+geom_blank())
  })
  
  observeEvent(input$ttestmu2Button3, {
    showElement(id = "ttestmu2box4div")
  })
  
  # Step 3B EDA div B 
  output$ttestmu2NumEDAB <- renderTable({
    switch(input$T2whichNumSumB,
           "Means"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=mean)
             names(my2TTab) <- c(input$selectV2a, paste0("Mean(",input$selectV2b,")"))
             my2TTab
           },
           "Sample Sizes"={
             my2TTab <- as.data.frame(table(ttestmu2dataSet()[[input$selectV2a]]))
             names(my2TTab) <- c(input$selectV2a, "n")
             my2TTab <- my2TTab[my2TTab[[input$selectV2a]]%in%(c(input$ttestmu2pop1, input$ttestmu2pop2)),]
             my2TTab
           },
           "Skewness"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=moments::skewness)
             names(my2TTab) <- c(input$selectV2a, paste0("Skewness(",input$selectV2b,")"))
             my2TTab
           },
           "Standard Deviations"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=sd)
             names(my2TTab) <- c(input$selectV2a, paste0("SD(",input$selectV2b,")"))
             my2TTab
           },
           "Medians"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=median)
             names(my2TTab) <- c(input$selectV2a, paste0("Median(",input$selectV2b,")"))
             my2TTab
           },
           "Modes"={
             my2TTab <- aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=getNumMode)
             names(my2TTab) <- c(input$selectV2a, paste0("Approx. Mode(",input$selectV2b,")"))
             my2TTab
           },
           "5 Number Summaries" = {
             my2TTab <- as.data.frame(aggregate(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet2(), FUN=quantile)[,-1])
             my2TTab[[input$selectV2a]] <- levels(ttestmu2dataSet2()[[input$selectV2a]])
             my2TTab <- my2TTab[,c(ncol(my2TTab),1:(ncol(my2TTab)-1))]
             names(my2TTab) <- c(input$selectV2a, "Min",paste0("Q",1:3), "Max")
             my2TTab
           },
           "Table of Counts" =data.frame(Msg="Tables not appropriate for quantitative data."),
           "Proportions"=data.frame(Msg="Proportions are not appropriate for quantitative data."),
           "---"=cat(" "))
  })
  
  output$ttestmu2PlotB <- renderPlot({
    switch(input$ttestmu2whichPlotB,
           "Histograms"= ggplot(ttestmu2dataSet2()[!is.na(ttestmu2dataSet2()[[input$selectV2a]]),], aes_string(x=input$selectV2b, fill=input$selectV2a)) +
             geom_histogram(binwidth=0.5, alpha=0.5),
           "Dotplots"=ggplot(ttestmu2dataSet2()[!is.na(ttestmu2dataSet2()[[input$selectV2a]]),], 
                             aes_string(x=input$selectV2b, fill=input$selectV2a))+geom_dotplot(alpha=0.5),
           "Boxplots"=ggplot(ttestmu2dataSet2()[!is.na(ttestmu2dataSet2()[[input$selectV2a]]),], 
                             aes_string(y=input$selectV2b, x=input$selectV2a)) +
             geom_boxplot(),
           "dens"=ggplot(ttestmu2dataSet2()[!is.na(ttestmu2dataSet2()[[input$selectV2a]]),], aes_string(x=input$selectV2b, color=input$selectV2a)) +
             geom_density(),
           "Barplots" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Pie Charts" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie Charts are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---"=ggplot()+geom_blank())
  })
  
  observeEvent(input$ttestmu2Button3B, {
    showElement(id = "ttestmu2box4divB") 
  })
  
  
  # Step 4 (Test) 
  output$ttestmu2TestOutput <- renderPrint({
    my2Ttest <- t.test(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(),
                       alternative=input$ttestmu2Alternative,
                       var.equal=TRUE,
                       conf.level=input$ttestmu2ConfLevel)
    my2TCI <- t.test(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(),
                     var.equal=TRUE,
                     conf.level=input$ttestmu2ConfLevel)$conf.int
    pops <- levels(ttestmu2dataSet()[[input$selectV2a]])
    cat(paste0("t Test for H0: Mean(", input$selectV2b,") for group"), pops[1], "=", 
        paste0("Mean(", input$selectV2b, ") for group"), pops[2],
        "\n",
        "Alternative Hypothesis = ", input$ttestmu2Alternative,
        "\n",
        "x-bar for group", pops[1],"=", my2Ttest$estimate[1],
        "\n",
        "x-bar for group", pops[2],"=", my2Ttest$estimate[2],
        "\n",
        "Difference in means =", my2Ttest$estimate[1]-my2Ttest$estimate[2],
        "\n",
        "t Test statistic =", my2Ttest$statistic, 
        "\n", 
        "p-value = ", my2Ttest$p.value,
        "\n",
        paste0(input$ttestmu2ConfLevel*100, "%"), "Conf. Int.:", my2TCI)
  })
  
  # Step 4 - The Test B Div
  output$ttestmu2TestOutputB <- renderPrint({
    # my2Ttest <- t.test(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(),
    #                    alternative=input$ttestmu2Alternative, 
    #                    var.equal=TRUE,
    #                    conf.level=input$ttestmu2ConfLevel)
    kp1 <- which(ttestmu2dataSet()[[input$selectV2a]]==input$ttestmu2pop1)
    kp2 <- which(ttestmu2dataSet()[[input$selectV2a]]==input$ttestmu2pop2)
    my2Ttest <- t.test(x=ttestmu2dataSet()[kp1,input$selectV2b],
                       y=ttestmu2dataSet()[kp2,input$selectV2b],
                       alternative=input$ttestmu2AlternativeB, 
                       var.equal=TRUE,
                       conf.level=input$ttestmu2ConfLevelB)
    # my2TCI <- t.test(formula=as.formula(paste(input$selectV2b,input$selectV2a,sep="~")), data=ttestmu2dataSet(),
    #                  var.equal=TRUE,
    #                  conf.level=input$ttestmu2ConfLevel)$conf.int
    my2TCI <- t.test(x=ttestmu2dataSet()[kp1,input$selectV2b],
                       y=ttestmu2dataSet()[kp2,input$selectV2b],
                       alternative="two.sided", 
                       var.equal=TRUE,
                       conf.level=input$ttestmu2ConfLevelB)
    #pops <- levels(ttestmu2dataSet()[[input$selectV2a]])
    pops <- c(input$ttestmu2pop1, input$ttestmu2pop2)
    cat(paste0("t Test for H0: Mean(", input$selectV2b,") for group"), pops[1], "=", 
        paste0("Mean(", input$selectV2b, ") for group"), pops[2],
        "\n",
        "Alternative Hypothesis = ", input$ttestmu2AlternativeB,
        "\n",
        "x-bar for group", pops[1],"=", my2Ttest$estimate[1],
        "\n",
        "x-bar for group", pops[2],"=", my2Ttest$estimate[2],
        "\n",
        "Difference in means =", my2Ttest$estimate[1]-my2Ttest$estimate[2],
        "\n",
        "t Test statistic =", my2Ttest$statistic, 
        "\n", 
        "p-value = ", my2Ttest$p.value,
        "\n",
        paste0(input$ttestmu2ConfLevelB*100, "%"), "Conf. Int.:", my2TCI$conf.int)
  })
  
  
  # One-Sample Z Test for Proportions --------------------------------------------------------
  # Step 1 (Select Dataset) ----
  
  output$ZtestP1Text <- renderText({
    paste("Description:",data.desc[[which(input$OneSampZTestPData==list.of.data.names)]])
  })
  
  ZPdataset <- reactive({
    hide("OneSampP1div")
    hide("OneSampP1div2")
    hide("OneSampP1div3")
    which.set <- which(input$OneSampZTestPData==list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$ZtestP1Table <- renderTable({
    head(ZPdataset())
  })
  
  output$ZtestP1N <- renderText({
    paste("Sample Size:", nrow(ZPdataset()))
  })
  
  output$ZtestP1header <- renderUI({
    tableOutput("ZtestP1Table")
  })
  
  observeEvent(input$ztestp1Button1, {
    showElement(id = "OneSampP1div")
  })
  
  # Step 2: Select Explanatory Variable ----
  output$ZtestP1Explanatory <- renderUI({
    Pvarnames <- names(ZPdataset())
    selectInput("Pselectv", label = "Please select the variable you wish to test:", choices = Pvarnames)
  })
  
  output$ZPTestCatError <- renderText(paste("<font color=\"#FF0000\">","Error: The variable you have selected is not categorical, hence, not approporiate
                                       for one-sample z test for proportions.  Please select a categorical (non-numeric) variable.", "</font>"))
  
  output$ZPTestCatCheckButton <- renderUI({
    if(!is.numeric(ZPdataset()[[input$Pselectv]])){
      actionButton("ztestp1Button2", label = "Proceed to EDA")
    } else {
      hide("OneSampP1div2")
      hide("OneSampP1div3")
      htmlOutput("ZPTestCatError")
    }
  })
  
  observeEvent(input$ztestp1Button2, {
    showElement(id = "OneSampP1div2")
  })
  
  
  # Step 3: EDA ----
  output$OneSampPNumOutput <- renderTable({
    switch(input$whichNumEDAP1,
           "Mean"=data.frame(Msg="The mean is not appropriate to calculate for categorical data."),
           "Standard Deviation"=data.frame(Msg="The std. deviation is not appropriate to calculate for categorical data."),
           "Median"=data.frame(Msg="The median is not appropriate to calculate for categorical data."),
           "Mode"={
             p1tab <- table(ZPdataset()[[input$Pselectv]], usaNA="no")
             data.frame(Msg=(paste("Mode =", names(p1tab)[which.max(p1tab)])))
           },
           "5 Number Summary" = myp1Tab <- data.frame(Msg="5 number summaries are not appropriate to calculate for categorical data."),
           "Table of Counts" = {
             myp1tab <- as.data.frame(addmargins(table(ZPdataset()[[input$Pselectv]], useNA="no")))
             names(myp1tab) <- c("Category", "Count")
             myp1tab
           },
           "Proportions"= {
             myp1tab <- as.data.frame(round(prop.table(table(ZPdataset()[[input$Pselectv]], useNA="no")), digits=3))
             names(myp1tab) <- c("Category", "Proportion")
             myp1tab
           },
           "---"=cat(" "))
  })
  
  output$OneSampPPlot <- renderPlot({
    switch(input$whichPlotP1, 
           "Pie Chart" = with(ZPdataset()[!is.na(ZPdataset()[[input$Pselectv]]),],{
             pie(table(get(input$Pselectv)),
                 col=rainbow(length(unique(get(input$Pselectv)))),
                 labels = paste(levels(get(input$Pselectv)),
                                paste0(round(table(get(input$Pselectv))/sum(table(get(input$Pselectv))),3)*100,"%")))
           }),
           "Bar Chart" = ggplot(ZPdataset()[!is.na(ZPdataset()[[input$Pselectv]]),], aes_string(x = input$Pselectv)) + geom_bar(),
           "Histogram"= ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Histograms are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Dotplot"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Dot plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Boxplot"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Boxplots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "dens"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Density plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---" = ggplot() + geom_blank()
    ) #end switch
  })
  
  observeEvent(input$ztestp1Button3, {
    showElement(id = "OneSampP1div3")
  })
  
  # Step 4: The Test ----
  output$ZPV <- renderUI({
    Pzvarnames <- levels(factor(ZPdataset()[[input$Pselectv]])) 
    selectInput("WhichCat", label = "Which category to do want to test?", choices = Pzvarnames)
  })
  
  output$OneSampP1Need <- renderPrint({
    n <- sum(!is.na(ZPdataset()[[input$Pselectv]]))
    phat <- sum(ZPdataset()[[input$Pselectv]] == input$WhichCat, na.rm=TRUE) / n
    pz <- (phat - input$Pnull) / sqrt(input$Pnull*(1-input$Pnull)/n)
    se.phat <- round(sqrt(phat*(1-phat)/n), digits = 3)
    p.conf.interval <- phat + c(-1,1) * qnorm(1-(1-input$OneSampPConfLevel)/2) * se.phat
    cat("p-hat:",round(phat,3),
        "\nStandard Error of p-hat:", se.phat, 
        "\nZ Test Statistic:",round(pz,3),
        "\nP-value: ", switch(input$WhichHypoP1,
                              "not equal to" = round(2*min(1-pnorm(pz), pnorm(pz)), digits = 3), 
                              ">" = round(1 - pnorm(pz), digits = 3),
                              "<" = round(pnorm(pz), digits = 3),
                              "---" = "---"
        ),
        "\nn = ", n, 
        "\n",paste0(100*input$OneSampPConfLevel, "% Confidence Interval:"), p.conf.interval
    )
    
  })
  
  
  # Two Sample Z Test for Proportions ------------------------------------------------------
  
  # Step 1: Select a Dataset ----
  output$ZtestP2Text <- renderText({
    paste("Description:",data.desc[[which(input$TwoSampZTestPData==list.of.data.names)]])
  })
  
  ZP2dataset <- reactive({
    hide("TwoSampP2div")
    hide("TwoSampP3div")
    hide("TwoSampP4div")
    hide("TwoSampP3divB")
    hide("TwoSampP4divB")
    which.set <- which(input$TwoSampZTestPData==list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$ZtestP2Table <- renderTable({
    head(ZP2dataset())
  })
  
  output$ZtestP2N <- renderText({
    paste("Sample Size:", nrow(ZP2dataset()))
  })
  
  output$ZtestP2header <- renderUI({
    tableOutput("ZtestP2Table")
  })
  
  observeEvent(input$ztestp2Button1, {
    showElement(id = "TwoSampP2div")
  })
  
  #Step 2: Select Population ----
  output$ZtestP2Population <- renderUI({
    P2varnames <- names(ZP2dataset())
    selectInput("P2selectpop", label = "Please select what variable defines the two populations:", choices = P2varnames)
  })
  
  output$ZtestP2VarName <- renderUI({
    P2varnames <- names(ZP2dataset())
    P2varnames <- P2varnames[P2varnames!=input$P2selectpop]
    selectInput("P2selectVar", label = "Please select what variable you wish to test:", choices = P2varnames)
  })
  
  output$ZtestP2Explanatory <- renderUI({
    ExpOptions <- levels(ZP2dataset()[,input$P2selectVar])
    selectInput("p2selectv", label = "Please select the level you wish to test:", choices = ExpOptions)
  })
  
  output$ZP2TestCatError <- renderText(paste("<font color=\"#FF0000\">","Error: The variables you have selected are not categorical, hence, not approporiate
                                       for two sample z test for proportions.  Please select categorical (non-numeric) variables.", "</font>"))
  
  output$ZP2TestCatCheckButton <- renderUI({
    if(!is.numeric(ZP2dataset()[[input$P2selectVar]]) & !is.numeric(ZP2dataset()[[input$P2selectpop]]) & nlevels(ZP2dataset()[[input$P2selectpop]]) >= 2 & (input$ZP2FirstPop != input$ZP2SecondPop)) {
      actionButton("ztestp2BButton3", label = "Proceed to EDA")
    } else {
      hide("TwoSampP3div")
      hide("TwoSampP4div")
      htmlOutput("ZP2TestCatError")
    }
  })
  
  # observeEvent(input$ztestp2Bbutton2, {
  #   showElement(id = "TwoSampP2Bdiv")
  # })
  
  observeEvent(input$ztestp2Button2, {
    showElement(id = "TwoSampP3div")
  })
  
  # Variable Selection Part 2 -- for populations with three or more levels
  output$ZP2ChoosePopLevelOne <- renderUI({
    if(!is.numeric(ZP2dataset()[[input$P2selectVar]]) & !is.numeric(ZP2dataset()[[input$P2selectpop]]) & nlevels(ZP2dataset()[[input$P2selectpop]]) >= 2){
      ZP2Levels <- levels(ZP2dataset()[[input$P2selectpop]])
      selectInput("ZP2FirstPop", label = 'Which level would you like to be "Group 1"?', choices = ZP2Levels)
    } 
  })
  
  output$ZP2ChoosePopLevelTwo <- renderUI({
    if(!is.numeric(ZP2dataset()[[input$P2selectVar]]) & !is.numeric(ZP2dataset()[[input$P2selectpop]]) & nlevels(ZP2dataset()[[input$P2selectpop]]) >= 2){
      ZP2Levels <- levels(ZP2dataset()[[input$P2selectpop]])
      ZP2Levels <- ZP2Levels[ZP2Levels!=input$ZP2FirstPop]
      selectInput("ZP2SecondPop", label = 'Which level would you like to be "Group 2"?', choices = ZP2Levels)
    } 
  })
  
  #### Testing this out so we don't have to add a bunch of new boxes of if/else statements
  ZP2dataset2 <- reactive({
    temporary <- ZP2dataset()
    temporary %>%
      dplyr::select(input$P2selectpop, input$P2selectVar) %>%
      dplyr::filter(temporary[,input$P2selectpop] == input$ZP2FirstPop | temporary[,input$P2selectpop] == input$ZP2SecondPop) %>%
      droplevels() 
  })
  
  observeEvent(input$ztestp2BButton3, {
    showElement(id = "TwoSampP3divB")
  })
  
  
  
  # Step 3: EDA ---- 
  # First Div EDA
  output$TwoSampPNumOutput <- renderTable({
    switch(input$whichNumEDAP2,
           "Means"=data.frame(Msg="Means are not appropriate to calculate for categorical data."),
           "Standard Deviations"=data.frame(Msg="Std. deviations are not appropriate to calculate for categorical data."),
           "Medians"=data.frame(Msg="Medians are not appropriate to calculate for categorical data."),
           "Modes"={
             p2tab <- table(ZP2dataset()[[input$P2selectpop]], ZP2dataset()[[input$P2selectVar]], useNA="no")
             data.frame(Msg=(paste("Mode for", levels(ZP2dataset()[[input$P2selectpop]])[1], "=", colnames(p2tab)[which.max(p2tab[1,])], ";",
                                   "Mode for", levels(ZP2dataset()[[input$P2selectpop]])[2], "=", colnames(p2tab)[which.max(p2tab[2,])])))
           },
           "5 Number Summaries" = data.frame(Msg="5 number summaries are not appropriate to calculate for categorical data."),
           "Table of Counts" = {
             myp2tab <- as.data.frame.matrix(addmargins(table(ZP2dataset()[[input$P2selectpop]], ZP2dataset()[[input$P2selectVar]], useNA="no")))
             #names(myp2tab) <- c(input$P2selectpop, input$P2selectVar, "Count")
             myp2tab
           },
           "Proportions"= {
             myp2tab <- as.data.frame.matrix(round(addmargins(prop.table(table(ZP2dataset()[[input$P2selectpop]],ZP2dataset()[[input$P2selectVar]], useNA="no"),
                                                                         margin=1)), 3))
             #names(myp2tab) <- c(input$P2selectpop, input$P2selectVar, "Proportion")
             myp2tab[-3,]
           },
           "---"=cat(" "))
  }, rownames=TRUE)
  
  output$TwoSampPPlot <- renderPlot({
    switch(input$WhichPlotP2, 
           "Pie Charts" = {
             par(mfrow=c(1,2))
             with(ZP2dataset()[ZP2dataset()[[input$P2selectpop]]==levels(ZP2dataset()[[input$P2selectpop]])[1] &
                                 !is.na(ZP2dataset()[[input$P2selectVar]]),],{
                                   pie(table(get(input$P2selectVar)),
                                       col=rainbow(length(unique(get(input$P2selectVar)))),
                                       labels = paste(levels(get(input$P2selectVar)),
                                                      paste0(round(table(get(input$P2selectVar))/sum(table(get(input$P2selectVar))),3)*100,"%")))
                                 })
             title(levels(ZP2dataset()[[input$P2selectpop]])[1])
             with(ZP2dataset()[ZP2dataset()[[input$P2selectpop]]==levels(ZP2dataset()[[input$P2selectpop]])[2] &
                                 !is.na(ZP2dataset()[[input$P2selectVar]]),],{
                                   pie(table(get(input$P2selectVar)),
                                       col=rainbow(length(unique(get(input$P2selectVar)))),
                                       labels = paste(levels(get(input$P2selectVar)),
                                                      paste0(round(table(get(input$P2selectVar))/sum(table(get(input$P2selectVar))),3)*100,"%")))
                                 })
             title(levels(ZP2dataset()[[input$P2selectpop]])[2])
           },
           "Bar Charts" = ggplot(ZP2dataset()[!is.na(ZP2dataset()[[input$P2selectVar]]) & !is.na(ZP2dataset()[[input$P2selectpop]]),], 
                                 aes_string(x = input$P2selectVar, fill=input$P2selectpop)) + 
             geom_bar(position="dodge"),
           "Histograms"= ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Histograms are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Dotplots"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Dot plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Boxplots"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Boxplots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "dens"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Density plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---" = ggplot() + geom_blank()
    ) #end switch
  })
  
  observeEvent(input$ztestp2Button3, {
    showElement(id = "TwoSampP4div")
  })
  
  #Second Div EDA
  output$TwoSampPNumOutputB <- renderTable({
    switch(input$whichNumEDAP2B,
           "Means"=data.frame(Msg="Means are not appropriate to calculate for categorical data."),
           "Standard Deviations"=data.frame(Msg="Std. deviations are not appropriate to calculate for categorical data."),
           "Medians"=data.frame(Msg="Medians are not appropriate to calculate for categorical data."),
           "Modes"={
             p2tab <- table(ZP2dataset2()[[input$P2selectpop]], ZP2dataset2()[[input$P2selectVar]], useNA="no")
             data.frame(Msg=(paste("Mode for", levels(ZP2dataset2()[[input$P2selectpop]])[1], "=", colnames(p2tab)[which.max(p2tab[1,])], ";",
                                   "Mode for", levels(ZP2dataset2()[[input$P2selectpop]])[2], "=", colnames(p2tab)[which.max(p2tab[2,])])))
           },
           "5 Number Summaries" = data.frame(Msg="5 number summaries are not appropriate to calculate for categorical data."),
           "Table of Counts" = {
             myp2tab <- as.data.frame.matrix(addmargins(table(ZP2dataset2()[[input$P2selectpop]], ZP2dataset2()[[input$P2selectVar]], useNA="no")))
             #names(myp2tab) <- c(input$P2selectpop, input$P2selectVar, "Count")
             myp2tab
           },
           "Proportions"= {
             myp2tab <- as.data.frame.matrix(round(addmargins(prop.table(table(ZP2dataset2()[[input$P2selectpop]],ZP2dataset2()[[input$P2selectVar]], useNA="no"),
                                                                         margin=1)), 3))
             #names(myp2tab) <- c(input$P2selectpop, input$P2selectVar, "Proportion")
             myp2tab[-3,]
           },
           "---"=cat(" "))
  }, rownames=TRUE)

  output$TwoSampPPlotB <- renderPlot({
    switch(input$WhichPlotP2B,
           "Pie Charts" = {
             par(mfrow=c(1,2))
             with(ZP2dataset2()[ZP2dataset2()[[input$P2selectpop]]==levels(ZP2dataset2()[[input$P2selectpop]])[1] &
                                 !is.na(ZP2dataset2()[[input$P2selectVar]]),],{
                                   pie(table(get(input$P2selectVar)),
                                       col=rainbow(length(unique(get(input$P2selectVar)))),
                                       labels = paste(levels(get(input$P2selectVar)),
                                                      paste0(round(table(get(input$P2selectVar))/sum(table(get(input$P2selectVar))),3)*100,"%")))
                                 })
             title(levels(ZP2dataset2()[[input$P2selectpop]])[1])
             with(ZP2dataset2()[ZP2dataset2()[[input$P2selectpop]]==levels(ZP2dataset2()[[input$P2selectpop]])[2] &
                                 !is.na(ZP2dataset2()[[input$P2selectVar]]),],{
                                   pie(table(get(input$P2selectVar)),
                                       col=rainbow(length(unique(get(input$P2selectVar)))),
                                       labels = paste(levels(get(input$P2selectVar)),
                                                      paste0(round(table(get(input$P2selectVar))/sum(table(get(input$P2selectVar))),3)*100,"%")))
                                 })
             title(levels(ZP2dataset2()[[input$P2selectpop]])[2])
           },
           "Bar Charts" = ggplot(ZP2dataset2()[!is.na(ZP2dataset2()[[input$P2selectVar]]) & !is.na(ZP2dataset2()[[input$P2selectpop]]),],
                                 aes_string(x = input$P2selectVar, fill=input$P2selectpop)) +
             geom_bar(position="dodge"),
           "Histograms"= ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Histograms are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Dotplots"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Dot plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Boxplots"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Boxplots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "dens"=ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Density plots are not appropriate for categorical data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---" = ggplot() + geom_blank()
    ) #end switch
  }) #end render plot

  observeEvent(input$ztestp2Button3B, {
    showElement(id = "TwoSampP4divB")
  })#end observe event and Second Div
  
  # Step 4: The test
  # First Div The test
  output$TwoSampP4test <- renderPrint ({
    cnt.table <- addmargins(table(ZP2dataset()[,input$P2selectVar],ZP2dataset()[,input$P2selectpop], useNA="no"))
    phat1 <- cnt.table[rownames(cnt.table)==input$p2selectv,1]/cnt.table[rownames(cnt.table)=="Sum",1]
    phat2 <- cnt.table[rownames(cnt.table)==input$p2selectv,2]/cnt.table[rownames(cnt.table)=="Sum",2]
    n1 <- cnt.table[rownames(cnt.table)=="Sum",1]
    n2 <- cnt.table[rownames(cnt.table)=="Sum",2]
    pooledphat <- (phat1*n1 + phat2*n2)/(n1+n2)
    p2z <- (phat1 - phat2) / sqrt(pooledphat *(1 - pooledphat)*(1/n1 + 1/n2))
    cat(" Population 1:", levels(ZP2dataset()[,input$P2selectpop])[1],
        "\n Population 2:", levels(ZP2dataset()[,input$P2selectpop])[2],
        "\n phat1 =", phat1,
        "\n phat2 =", phat2,
        "\n phat1-phat2 =", phat1-phat2,
        "\n Test Statistic (Z) =", round(p2z, digits = 3),
        "\n P-value: ",
        switch(input$WhichHypoP2,
               "not equal to" = round(2*min(1-pnorm(p2z), pnorm(p2z)), digits = 3),
               ">" = round(1 - pnorm(p2z), digits = 3),
               "<" = round(pnorm(p2z), digits = 3),
               "---" = "---"
        ),
        "\n",
        paste0(c(input$TwoSampPConfLevel*100,
                 "% Confidence Interval: ",
                 round((phat1 - phat2) + c(-1, 1)*qnorm(1-(1-input$TwoSampPConfLevel)/2)*sqrt((phat1*(1-phat1)/n1) + (phat2*(1-phat2))/n2), digits = 5)))
        #end switch
    ) #end cat
  })
  
  # Second Div The test
  output$ZtestP2ExplanatoryB <- renderUI({
    selectInput("p2selectvB", "Select the level of the response variable you would like to test", choices = levels(ZP2dataset2()[,input$P2selectVar]))
  })
  
  output$TwoSampP4testB <- renderPrint ({
    cnt.table <- addmargins(table(ZP2dataset2()[,input$P2selectVar],ZP2dataset2()[,input$P2selectpop], useNA="no"))
    phat1 <- cnt.table[rownames(cnt.table)==input$p2selectvB,1]/cnt.table[rownames(cnt.table)=="Sum",1]
    phat2 <- cnt.table[rownames(cnt.table)==input$p2selectvB,2]/cnt.table[rownames(cnt.table)=="Sum",2]
    n1 <- cnt.table[rownames(cnt.table)=="Sum",1]
    n2 <- cnt.table[rownames(cnt.table)=="Sum",2]
    pooledphat <- (phat1*n1 + phat2*n2)/(n1+n2)
    p2z <- (phat1 - phat2) / sqrt(pooledphat *(1 - pooledphat)*(1/n1 + 1/n2))
    cat(" Population 1:", levels(ZP2dataset2()[,input$P2selectpop])[1],
        "\n Population 2:", levels(ZP2dataset2()[,input$P2selectpop])[2],
        "\n phat1 =", phat1,
        "\n phat2 =", phat2,
        "\n phat1-phat2 =", phat1-phat2,
        "\n Test Statistic (Z) =", round(p2z, digits = 3),
        "\n P-value: ",
        switch(input$WhichHypoP2B,
               "not equal to" = round(2*min(1-pnorm(p2z), pnorm(p2z)), digits = 3),
               ">" = round(1 - pnorm(p2z), digits = 3),
               "<" = round(pnorm(p2z), digits = 3),
               "---" = "---"
        ),
        "\n",
        paste0(c(input$TwoSampPConfLevelB*100,
                 "% Confidence Interval: ",
                 round((phat1 - phat2) + c(-1, 1)*qnorm(1-(1-input$TwoSampPConfLevelB)/2)*sqrt((phat1*(1-phat1)/n1) + (phat2*(1-phat2))/n2), digits = 5)))
        #end switch
    ) #end cat
  }) #end Second Div The Test
  
  # ANOVA ------------------------------------------------------------------------
  # ANOVA Step 1 (select dataset) ----------------------------------
  
  output$TextANOVA <- renderText({
    paste("Description:", data.desc[[which(input$DataANOVA==list.of.data.names)]])
  })
  
  anovadataSet <- reactive({
    hide("anovadiv")
    hide("anovabox3div")
    hide("anovabox4div")
    which.set <- which(input$DataANOVA==list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$TableANOVA <- renderTable({
    head(anovadataSet())
  })
  
  output$nANOVA <- renderText({
    paste("Sample Size:", nrow(anovadataSet()))
  })
  
  output$dataHeaderANOVA <- renderUI({
    tableOutput("TableANOVA")
  })
  
  observeEvent(input$ANOVAButton1, {
    showElement(id = "anovadiv")
  })
  
  # ANOVA Step 2 (select explanatory variables)---
  
  # Step 2 (select samp1 and samp2 var.)----
  
  output$anovagroup <- renderUI({
    groupNamesANOVA <- names(anovadataSet())
    selectInput("anovaGroup",
                label="Please select the categorical variable that distinguishes the three or more groups:",
                choices=groupNamesANOVA)
  })
  
  output$ANOVAgroupLevels <- renderPrint({
    if(nlevels(anovadataSet()[[input$anovaGroup]])==2){
      cat("Number of groups (levels) in",input$anovaGroup,"is 2.  Please select a different categorical variable to distinguishes the THREE or MORE groups")
    } else {
      cat("Group labels:",levels(anovadataSet()[[input$anovaGroup]]))
    }
  })
  
  output$anovavar <- renderUI({
    varNamesANOVA <- names(anovadataSet())
    selectInput("anovaVar",
                label="Please select the quantitative variable you wish to test:",
                choices=varNamesANOVA)
  })
  
  output$AnovaError <- renderText(paste("<font color=\"#FF0000\">","Error: One or more of the variables you have input are not of the correct type, hence, not approporiate
                                       for an Analysis of Variance.  Please select a categorical (non-numeric) variable to select groups and then a quantitative variable for testing.", "</font>"))
  
  output$AnovaCheckButton <- renderUI({
    if(!is.numeric(anovadataSet()[[input$anovaGroup]]) & is.numeric(anovadataSet()[[input$anovaVar]])){
      actionButton("ANOVAButton2", label = "Proceed to EDA")
    } else {
      hide("anovabox3div")
      hide("anovabox4div")
      htmlOutput("AnovaError")
    }
  })
  
  observeEvent(input$ANOVAButton2, {
    showElement(id = "anovabox3div")
  })
  
  # Step 3 (EDA)
  output$anovaNumEDA <- renderTable({
    switch(input$ANOVAwhichNumSum,
           "Sample sizes"={
             myANOVATab <- data.frame(PlaceHolder=levels(anovadataSet()[[input$anovaGroup]]), SampleSize=as.numeric(table(anovadataSet()[[input$anovaGroup]])))
             names(myANOVATab)[1] <- input$anovaGroup
             myANOVATab
           },
           "Means"={
             myANOVATab <- aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=mean)
             names(myANOVATab) <- c(input$anovaGroup, paste0("Mean(",input$anovaVar,")"))
             myANOVATab
           },
           "Skewness"={
             myANOVATab <- aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=moments::skewness)
             names(myANOVATab) <- c(input$anovaGroup, paste0("Skewness(",input$anovaVar,")"))
             myANOVATab
           },
           "Standard Deviations"={
             myANOVATab <- aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=sd)
             names(myANOVATab) <- c(input$anovaGroup, paste0("SD(",input$anovaVar,")"))
             myANOVATab
           },
           "Medians"={
             myANOVATab <- aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=median)
             names(myANOVATab) <- c(input$anovaGroup, paste0("Median(",input$anovaVar,")"))
             myANOVATab
           },
           "Modes"={
             myANOVATab <- aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=getNumMode)
             names(myANOVATab) <- c(input$anovaGroup, paste0("Approx. Mode(",input$anovaVar,")"))
             myANOVATab
           },
           "5 Number Summaries" = {
             myANOVATab <- as.data.frame(aggregate(formula=as.formula(paste(input$anovaVar,input$anovaGroup,sep="~")), data=anovadataSet(), FUN=quantile)[,-1])
             validLevels <- table(anovadataSet()[[input$anovaGroup]])
             validLevels <- names(validLevels)[validLevels>0]
             myANOVATab[[input$anovaGroup]] <- validLevels
             myANOVATab <- myANOVATab[,c(ncol(myANOVATab),1:(ncol(myANOVATab)-1))]
             names(myANOVATab) <- c(input$anovaGroup, "Min",paste0("Q",1:3), "Max")
             myANOVATab
           },
           "Table of Counts" =data.frame(Msg="Tables not appropriate for quantitative data."),
           "Proportions"=data.frame(Msg="Proportions are not appropriate for quantitative data."),
           "---"=cat(" "))
  })
  
  output$anovaPlot <- renderPlot({
    switch(input$anovawhichPlot,
           "Boxplots"= ggplot(anovadataSet()[complete.cases(anovadataSet()[,c(input$anovaGroup, input$anova)]),], aes_string(x=input$anovaGroup, y=input$anovaVar)) +
             geom_boxplot(),
           "Histograms"= ggplot(anovadataSet()[complete.cases(anovadataSet()[,c(input$anovaGroup, input$anova)]),],
                                aes_string(x=input$anovaVar)) +
             geom_histogram() + facet_wrap(as.formula(paste0("~",input$anovaGroup))),
           "Dotplots"=ggplot(anovadataSet(),aes_string(x=input$anovaVar))+geom_dotplot(alpha=0.5) + facet_wrap(as.formula(paste0("~",input$anovaGroup))),
           "dens"=ggplot(anovadataSet(), aes_string(x=input$anovaVar, color=input$anovaGroup)) + geom_density(show.legend=FALSE) + 
             stat_density(aes_string(x=input$anovaVar, color=input$anovaGroup), geom="line",position="identity"),
           "Barplots" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Barplots are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "Pie Charts" = ggplot(data.frame(x=0,y=0), aes(x=x, y=y, label="Pie Charts are not appropriate for quantitative data")) + geom_label() +
             xlab("") + ylab("") + theme(axis.text = element_blank()),
           "---"=ggplot()+geom_blank())
  })
  
  observeEvent(input$ANOVAButton3, {
    showElement(id = "anovabox4div")
  })
  
  # Step 4 (Test)
  output$anovaTest <- renderPrint({
    anova.lm.f <- summary(lm(as.formula(paste0(c(input$anovaVar, input$anovaGroup), collapse="~")), data=anovadataSet()))[['fstatistic']]
    cat("ANOVA (F-test) if means are equal",
        "\n F-statistic:", anova.lm.f[1],
        "\n p-value =",  round(pf(anova.lm.f[1], anova.lm.f[2], anova.lm.f[3], lower=FALSE),5)
    ) #end cat
  })
  
  anova.conf <- reactive({
    anova.lm <- lm(as.formula(paste0(paste0(c(input$anovaVar, input$anovaGroup), collapse="~"), "-1")), data=anovadataSet())
    conf_ints <- confint(anova.lm, level=input$ANOVAConfLevel)
    categories <- levels(factor(anovadataSet()[[input$anovaGroup]]))
    data.frame("category" = categories, "lb" = conf_ints[,1], "ub" = conf_ints[,2], "means"=coef(anova.lm))
  })
  
  output$errorbars <- renderPlot({
    ggplot(data = anova.conf()) +
      geom_errorbarh(mapping = aes(y = anova.conf()[["category"]], xmin = anova.conf()[["lb"]], xmax = anova.conf()[["ub"]])) +
                       labs(x = input$anovaVar, y = input$anovaGroup) +
      geom_point(aes(y=anova.conf()[["category"]], x=anova.conf()[['means']]))
  })

  
  ## as.formula(paste(input$anovaVar, input$anovaGroup, sep="~"))
  
  
  # end ANOVA tab
  
  
  
  # Regression -------------------------------------------------------------------
  # Regression Step 1 (select dataset)------------------------------------------------------------
  
  output$regText <- renderText({
    paste("Description:",data.desc[[which(input$regData==list.of.data.names)]])
  })
  
  dataSet <- reactive({
    hide("regbox2div")
    hide("regbox3div")
    hide("regbox4div")
    hide("regbox5div")
    hide("regbox6div")
    which.set <- which(input$regData==list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$dataTable <- renderTable({
    head(dataSet())
  })
  
  output$regN <- renderText({
    paste("Sample size:",nrow(dataSet()))
  })
  
  output$dataHeader <- renderUI({
    tableOutput("dataTable")
  })
  
  observeEvent(input$regButton1, {
    showElement(id = "regbox2div")
  })
  
  # Regression Step 2 (select exp. var.)---------------------------
  
  output$Explanatory <- renderUI({
    varNames <- names(dataSet())
    selectInput("selectIV",
                label="Select Explanatory Variable:",
                choices=varNames)
  })
  
  output$ExVars <- renderUI({
    varNames <- names(dataSet())
    checkboxGroupInput("selectEVs",
                       label="Select explanatory variables(s):",
                       choices=varNames)
  })
  
  output$Response <- renderUI({
    varNames <- names(dataSet())
    selectInput("selectDV",
                label="Select Response Variable:",
                choices=varNames)
  })
  
  output$reg2 <- renderText(
    "Please select the explanatory variable.  The explanatory variable should
    \"explain\" what happens to the response variable."
  )
  
  ## attempt 6 wahoooooo
  output$RegQuantError <- renderText(paste("<font color=\"#FF0000\">","Error: At least one of the variables you have selected is not quantitative, hence, not approporiate
                                       for linear regression.  Please select quantitative (numeric) explanatory and response variables.", "</font>"))
  
  output$RegVarsCheckButton <- renderUI({
    if(is.numeric(dataSet()[[input$selectDV]]) & is.numeric(dataSet()[[input$selectIV]])){
      actionButton("regButton2", label = "Proceed to EDA")
    } else {
      hide("regbox3div")
      hide("regbox4div")
      hide("regbox5div")
      hide("regbox6div")
      htmlOutput("RegQuantError")
    }
  })
  
  
  
  observeEvent(input$regButton2, {
    showElement(id = "regbox3div")
  })
  
  
  # Regression Step 3 (Show scatterplot)-------------------------
  output$regNumEDA <- renderPrint({
    switch(input$regWhichNumEDA,
           "---"=cat(" "), 
           "Mean of Explanatory Variable"=cat(paste("Mean of X =", round(mean(dataSet()[[input$selectIV]], na.rm=TRUE),3))), 
           "Mean of Response Variable"=cat(paste("Mean of Y =", round(mean(dataSet()[[input$selectDV]], na.rm=TRUE),3))),
           "Std. Dev. of Explanatory Variable"=cat(paste("SD of X =", round(sd(dataSet()[[input$selectIV]], na.rm=TRUE),3))),
           "Std. Dev. of Response Variable"=cat(paste("SD of Y =", round(sd(dataSet()[[input$selectDV]], na.rm=TRUE),3))),
           "Median of Explanatory Variable"=cat(paste("Median of X =", round(median(dataSet()[[input$selectIV]], na.rm=TRUE),3))),
           "Median of Response Variable"=cat(paste("Median of Y =", round(median(dataSet()[[input$selectDV]], na.rm=TRUE),3))),
           "Mode of Explanatory Variable"=cat(paste("(Approximate) Mode of X =", round(density(dataSet()[[input$selectIV]], na.rm=TRUE)$x[which.max(density(dataSet()[[input$selectIV]], na.rm=TRUE)$y)],3))),
           "Mode of Response Variable"=cat(paste("(Approximate) Mode of Y =", round(density(dataSet()[[input$selectDV]], na.rm=TRUE)$x[which.max(density(dataSet()[[input$selectDV]], na.rm=TRUE)$y)],3))),
           "Correlation between Explanatory and Response Variable"=cat(paste("Correlation (r) =", round(cor(dataSet()[[input$selectIV]], dataSet()[[input$selectDV]], use="complete.obs"),4))),
           "Covariance between Explanatory and Response Variable"=cat(paste("Covariance =", round(cov(dataSet()[[input$selectIV]], dataSet()[[input$selectDV]], use="complete.obs"),4)))
           ) #End Switch
  })
  
  ## Add reactive to input$whichPlot
  output$regPlot <- renderPlot({
    switch(input$whichPlot,
           "Histogram of Explanatory Variable"=ggplot(dataSet(),aes_string(x=input$selectIV))+geom_histogram(col="gray"),
           "Histogram of Response Variable"=ggplot(dataSet(),aes_string(x=input$selectDV))+geom_histogram(col="gray"),
           "Density of Explanatory Variable"=ggplot(dataSet(),aes_string(x=input$selectIV))+geom_density(),
           "Density of Response Variable"=ggplot(dataSet(),aes_string(x=input$selectDV))+geom_density(),
           "Scatterplot"=ggplot(dataSet(),aes_string(x=input$selectIV,y=input$selectDV))+geom_point(),
           "---"=ggplot()+geom_blank())
  })
  
  output$varSum <- renderPrint({
    switch(input$whichPlot,
           "Histogram of Explanatory Variable"=summary(dataSet()[[input$selectIV]])
    )
  })
  
  observeEvent(input$regButton3, {
    showElement(id = "regbox4div")
  })
  
  #Regression Section 4 (Assumptions) ------------------------------
  
  lm1 <- reactive({
    lm(reformulate(input$selectIV, response=input$selectDV), data = dataSet())
  }) 
  
  
  output$regA <- renderText({
    "Check if the assumptions are met for a linear regression"
  })
  
  output$residPlot <- renderPlot({
    switch(input$regAssumption,
           "Scatterplot (Linearity)"=ggplot(dataSet(),aes_string(x=input$selectIV,y=input$selectDV))+geom_point(),
           "Histogram of Residuals (Normality)"=ggplot()+geom_histogram(aes(x=stdres(lm1()))) + xlab("Standardized Residuals"),
           "Fitted vs. Residuals (Equal Variance)"=ggplot()+geom_point(aes(x=lm1()$fitted,y=stdres(lm1()))) + xlab("Fitted Values") + ylab("Standardized Residuals"),
           "---"=ggplot()+geom_blank()
    ) #End Switch
  })
  
  observeEvent(input$regButton4, {
    showElement(id = "regbox5div")
  })
  
  # Regression Section 5 (Fit Regression Line)---------------------------

  output$regCoefText <- renderText({
    paste("Regression Analysis of", input$selectDV, "(Y) explained by", input$selectIV, "(X)",
        "\nCoefficient Table:")
  })
  
  output$regCoefTable <- renderTable({
    coefTable <- summary(lm1())$coef
    confInts <- confint(lm1(), level=input$betaConfLevel)
    coefTable <- cbind(coefTable, "CI Lower Bound"=confInts[,1], "CI Upper Bound"=confInts[,2])
  }, rownames = TRUE)
  
  output$regSummary <- renderPrint({
    cat("R-squared: ", summary(lm1())$r.squared,
        "\nsigma: ", summary(lm1())$sigma
    ) #end cat
  })
  
  output$corPlot <- renderPlot({
    ggplot(dataSet(),aes_string(x=input$selectIV,y=input$selectDV))+ geom_point() + 
      geom_smooth(method="lm", se=FALSE)
  })
  
  observeEvent(input$regButton5, {
    showElement(id = "regbox6div")
  })
  
  # Regression Section 6 (Prediction) ----------------------
  
  output$prediction <- renderText({
    new.df <- data.frame(x=input$RegPredict)
    names(new.df) <- input$selectIV
    myPredTable <- switch(input$ConfOrPredInt,
           "Confidence Interval" = predict.lm(lm1(), newdata = new.df, interval = "confidence", level = input$RegConfLevel),
           "Prediction Interval" = predict.lm(lm1(), newdata = new.df, interval = "prediction", level = input$RegConfLevel)
    ) #End Switch
    int.type <- switch(input$ConfOrPredInt,
                       "Confidence Interval" = "Confidence",
                       "Prediction Interval" = "Prediction"
                       ) #End Switch
    paste0("Prediction for ", input$selectDV, " when ", input$selectIV, "=", input$RegPredict,
        "\nPrediction: ", round(myPredTable[1],3),
        "\n", input$RegConfLevel*100, "% ", int.type, " Interval: (", round(myPredTable[2],3), ",", round(myPredTable[3],3), ")"
    ) #end paste0
  })
  
  observeEvent(input$regStartOver, {
    hide("regbox2div")
    hide("regbox3div")
    hide("regbox4div")
    hide("regbox5div")
    hide("regbox6div")
  })
  
  # output$corOutput <- renderPrint(cor(MPGData$Weight, MPGData$MPG))
  # output$corOutput <- renderPrint(cor(get(paste(input$regData, "$", input$selectIV, sep = "")),
  # get(paste(input$regData, "$", input$selectDV, sep = "")))) 
  
  # output$corOutput <- renderPrint({
  #   if (input$regData == "Windmills") {
  #     cor(MPG$get(input$selectIV), MPG$get(selectDV))
  #   }
  #   if (input$regData == "MPG") {
  #     cor(MPG$get(input$selectIV), MPG$get(selectDV))
  #   }
  # })
  
  # Chi-square -------------------------------------------------------------------
  # Chi-square Step 1 (select dataset)------------------------------------------------------------
  
  output$chisqText <- renderText({
    paste("Description:",data.desc[[which(input$chisqData==list.of.data.names)]])
  })
  
  ChiSqdataSet <- reactive({
    hide("chisqbox2div")
    hide("chisqbox3div")
    hide("chisqbox4div")
    which.set <- which(input$chisqData==list.of.data.names)
    read.table(paste0("./Datasets/", list.of.data.files[which.set]), header=TRUE,
                 sep=list.of.data.seps[which.set], stringsAsFactors = TRUE)
  })
  
  output$chisqN <- renderText({
    paste("Sample size:",nrow(ChiSqdataSet()))
  })
  
  output$ChiSqdataTable <- renderTable({
    head(ChiSqdataSet())
  })
  
  output$ChiSqdataHeader <- renderUI({
    tableOutput("ChiSqdataTable")
  })
  
  observeEvent(input$chiSqButton1, {
    showElement(id = "chisqbox2div")
  })
  
  # Chi-square Step 2 (select variables)------------------------------------------------------------
  output$Chi2text2 <- renderText("Please select which variables to put as the row and column variables.")
  
  output$Chi2Row <- renderUI({
    varNames <- names(ChiSqdataSet())
    selectInput("Chi2selectRow",
                label="Select Row Variable:",
                choices=varNames)
  })
  
  output$Chi2Column <- renderUI({
    varNames <- names(ChiSqdataSet())
    selectInput("Chi2selectCol",
                label = "Select Column Variable:",
                choices = varNames)
  })
  
  output$ChiSqError <- renderText(paste("<font color=\"#FF0000\">","Error: At least one of the variables you have selected is not categorical, hence, not approporiate
                                       for a Chi Square Test for Independence.  Please select categorical (non-numeric) explanatory and response variables.", "</font>"))
  
  output$ChiSqVarsCheckButton <- renderUI({
    if(!is.numeric(ChiSqdataSet()[[input$Chi2selectRow]]) & !is.numeric(ChiSqdataSet()[[input$Chi2selectRow]])){
      actionButton("chiSqButton2", label = "Proceed to EDA")
    } else {
      hide("chisqbox3div")
      hide("chisqbox4div")
      htmlOutput("ChiSqError")
    }
  })
  
  observeEvent(input$chiSqButton2, {
    showElement(id = "chisqbox3div")
  })
  
  # Chi-square Step 3 (EDA) ------------------------------------------------------------
  output$ChiSqNumEDA <- renderTable({
    switch(input$ChiSqNumSum,
           "Counts of Row Variable"=with(ChiSqdataSet(),{
             xTab <- t(as.matrix(addmargins(table(get(input$Chi2selectRow), useNA="no"))))
             rownames(xTab) <- "Count"
             xTab}),
           "Counts of Column Variable"=with(ChiSqdataSet(),{
             xTab <- t(as.matrix(addmargins(table(get(input$Chi2selectCol), useNA="no"))))
             rownames(xTab) <- "Count"
             xTab}),
           "Two Way Table of Counts" = with(ChiSqdataSet(),{
             as.data.frame.matrix(addmargins(table(get(input$Chi2selectRow),get(input$Chi2selectCol), useNA="no")))}),
           "Conditional Distribution of Column given Row" = with(ChiSqdataSet(),{
             as.data.frame.matrix(addmargins(prop.table(table(get(input$Chi2selectRow),get(input$Chi2selectCol), useNA="no"), margin = 1)))}),
           "Conditional Distribution of Row given Column" = with(ChiSqdataSet(),{
             as.data.frame.matrix(addmargins(prop.table(table(get(input$Chi2selectRow),get(input$Chi2selectCol), useNA="no"), margin = 2)))})
    ) #End Switch
  }, rownames=TRUE)
  
  output$ChiSqPlotEDA <- renderPlot({
    switch(input$ChiSqwhichPlot,
           "Barplot of Row Variable"=
             ggplot(ChiSqdataSet()[!is.na(ChiSqdataSet()[[input$Chi2selectRow]]),], 
                    aes_string(x=input$Chi2selectRow))+geom_bar(),
           "Barplot of Column Variable"=
             ggplot(ChiSqdataSet()[!is.na(ChiSqdataSet()[[input$Chi2selectCol]]),],aes_string(x=input$Chi2selectCol))+geom_bar(),
           "Piechart of Row Variable"= with(ChiSqdataSet()[!is.na(ChiSqdataSet()[[input$Chi2selectRow]]),],{
             pie(table(get(input$Chi2selectRow)),
                 col=rainbow(length(unique(get(input$Chi2selectRow)))),
                 labels = paste(levels(get(input$Chi2selectRow)),
                                paste0(round(table(get(input$Chi2selectRow))/sum(table(get(input$Chi2selectRow))),3)*100,"%")))}),
           "Piechart of Column Variable"= with(ChiSqdataSet()[!is.na(ChiSqdataSet()[[input$Chi2selectCol]]),],{
             pie(table(get(input$Chi2selectCol)),
                 col=rainbow(length(unique(get(input$Chi2selectCol)))),
                 labels=paste(levels(get(input$Chi2selectCol)),
                              paste0(round(table(get(input$Chi2selectCol))/sum(table(get(input$Chi2selectCol))),3)*100,"%")))}),
             "---"= ggplot(ChiSqdataSet(), aes_string(x=input$Chi2selectRow)) + geom_blank()
    ) #End Switch
  }) #End renderPlot
  
  observeEvent(input$chiSqButton3, {
    showElement(id = "chisqbox4div")
  })
  
  # Chi-square Step 4 (Test) ------------------------------------------------------------
  output$ChiSqTestText <- renderPrint({
    cat("Chi-square Test of association between", input$Chi2selectRow, "and", input$Chi2selectCol)
  })
  
  output$ChiSqEVText <- renderPrint({
    cat("Expected Value Table:")
  })
  
  output$ExpectedCounts <- renderTable({
    test_chisq <- chisq.test(table(ChiSqdataSet()[[input$Chi2selectRow]],ChiSqdataSet()[[input$Chi2selectCol]], useNA = "no"))
    test_chisq$expected
  }, rownames = TRUE)
  
  output$ChiSqCompText <- renderPrint({
    cat("Chi-square Component Table [(O - E)^2 / E]:")
  })
  
  output$ChiSqComponents <- renderTable({
    test_chisq <- chisq.test(table(ChiSqdataSet()[[input$Chi2selectRow]],ChiSqdataSet()[[input$Chi2selectCol]], useNA = "no"))
    as.data.frame.matrix(test_chisq$residuals^2)
  }, rownames = TRUE)
  
  output$ChiSqTest <- renderPrint({
    test_chisq <- chisq.test(table(ChiSqdataSet()[[input$Chi2selectRow]],ChiSqdataSet()[[input$Chi2selectCol]]))
    cat("Overall Chi-square (test statistic): ", test_chisq$statistic, 
        "\np-value = ",  test_chisq$p.value
    ) #end cat
  })
  
  # Normal Probability Calculator -----------------------------------------------------------------
  
  output$Zprob <- renderText({
    theprob <- switch(input$Tail,
                      "Upper Tail" = pnorm((input$Zscore-input$NormProbMean)/input$NormProbStd, lower.tail = FALSE),
                      "Lower Tail" = pnorm((input$Zscore-input$NormProbMean)/input$NormProbStd),
                      "Between" = pnorm((max(input$Zscore2,input$Zscore)-input$NormProbMean)/input$NormProbStd) - 
                                          pnorm((min(input$Zscore2,input$Zscore)-input$NormProbMean)/input$NormProbStd)) #end switch
    paste("Probability",round(theprob,4),sep="=")
  }) #end renderPrint
  
  output$NormPct <- renderText({
    thepct <- switch(input$PctTail,
                     "Upper Tail" = qnorm(input$Normprob, mean = input$NormPctMean, sd=input$NormPctStd, lower.tail=FALSE),
                     "Lower Tail" = qnorm(input$Normprob, mean = input$NormPctMean, sd=input$NormPctStd),
                     "Between" = sort(c(qnorm(input$Normprob, mean = input$NormPctMean, sd=input$NormPctStd),
                                        qnorm(input$Normprob2, mean = input$NormPctMean, sd=input$NormPctStd))))
    if(input$PctTail=="Between"){
      the.msg <- paste(diff(sort(c(input$Normprob, input$Normprob2)))*100, "% is between ", round(thepct[1],4),
                      ' and ', round(thepct[2],4), sep="") 
    } else if(input$PctTail=="Upper Tail") {
      the.msg <- paste0(input$Normprob*100, "% is above ", round(thepct[1],4))
    } else {
      the.msg <- paste0(input$Normprob*100, "% is below ", round(thepct[1],4))
    }
    the.msg
  })
  
  output$NormalAreaShaded <- renderPlot({
    switch(input$Tail,
           "Upper Tail" = ggplot(data.frame(x = c(input$NormProbMean-4*input$NormProbStd, input$NormProbMean+4*input$NormProbStd)), aes(x = x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormProbMean, sd=input$NormProbStd)) + 
             stat_function(fun = dnorm, xlim = c(input$Zscore, input$NormProbMean+4*input$NormProbStd),
                           geom = "area", fill = " blue", alpha = .2, args=list(mean=input$NormProbMean, sd=input$NormProbStd)) +
             labs(y = "Density", x = "Value"),
           "Lower Tail" = ggplot(data.frame(x = c(input$NormProbMean-4*input$NormProbStd, input$NormProbMean+4*input$NormProbStd)), aes(x = x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormProbMean, sd=input$NormProbStd)) + 
             stat_function(fun = dnorm, xlim = c(input$NormProbMean-4*input$NormProbStd, input$Zscore),
                           geom = "area", fill = " blue", alpha = .2, args=list(mean=input$NormProbMean, sd=input$NormProbStd)) +
             labs(y = "Density", x = "Value"),
           "Between" = ggplot(data.frame(x = c(input$NormProbMean-4*input$NormProbStd, input$NormProbMean+4*input$NormProbStd)), aes(x=x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormProbMean, sd=input$NormProbStd)) +
             stat_function(fun = dnorm, xlim = c(min(input$Zscore,input$Zscore2), 
                                                 max(input$Zscore,input$Zscore2)),
                           geom = "area", fill = "blue", alpha = 0.2, args=list(mean=input$NormProbMean, sd=input$NormProbStd)) + 
             labs(y = "Density", x = "Value")
    ) #end switch
  }) #end renderPlot
  
  output$NormalPctAreaShaded <- renderPlot({
    switch(input$PctTail,
           "Upper Tail" = ggplot(data.frame(x = c(input$NormPctMean-4*input$NormPctStd, input$NormPctMean+4*input$NormPctStd)), aes(x = x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormPctMean, sd=input$NormPctStd)) + 
             stat_function(fun = dnorm, xlim = c(qnorm(input$Normprob, mean=input$NormPctMean, sd=input$NormPctStd, lower.tail=FALSE), input$NormPctMean+4*input$NormPctStd),
                           geom = "area", fill = " blue", alpha = .2, args=list(mean=input$NormPctMean, sd=input$NormPctStd)) +
             labs(y = "Density", x = "Value"),
           "Lower Tail" = ggplot(data.frame(x = c(input$NormPctMean-4*input$NormPctStd, input$NormPctMean+4*input$NormPctStd)), aes(x = x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormPctMean, sd=input$NormPctStd)) + 
             stat_function(fun = dnorm, xlim = c(input$NormPctMean-4*input$NormPctStd, qnorm(input$Normprob, mean=input$NormPctMean, sd=input$NormPctStd)),
                           geom = "area", fill = " blue", alpha = .2, args=list(mean=input$NormPctMean, sd=input$NormPctStd)) +
             labs(y = "Density", x = "Value"),
           "Between" = ggplot(data.frame(x = c(input$NormPctMean-4*input$NormPctStd, input$NormPctMean+4*input$NormPctStd)), aes(x=x)) + 
             stat_function(fun = dnorm, col = "black", args=list(mean=input$NormPctMean, sd=input$NormPctStd)) +
             stat_function(fun = dnorm, xlim = c(qnorm(min(input$Normprob,input$Normprob2), mean=input$NormPctMean, sd=input$NormPctStd), 
                                                 qnorm(max(input$Normprob,input$Normprob2),mean=input$NormPctMean, sd=input$NormPctStd)),
                           geom = "area", fill = "blue", alpha = 0.2, args=list(mean=input$NormPctMean, sd=input$NormPctStd)) + 
             labs(y = "Density", x = "Value")
    ) #end switch
  }) #end renderPlot
  
  # Sampling Distribution of Xbar ------------------------------------------------------
  
  # Stable vars to use when adding one sample at a time
  means <- NULL
  means_offset <- 0
  
  # Reactive expression to generate the requested distribution.
  # This is called whenever the inputs change. The output
  # functions defined below then all use the value computed from
  # this expression
  data <- reactive({
    dist <- switch(input$dist,
                   norm = rnorm,
                   unif = runif,
                   beta = rbeta,
                   exp = rexp,
                   rnorm)
    
    # in addition to input$dist and input$n react to changes in...
    input$resample
    
    if(input$dist=="beta"){
      dist(input$n, shape1=5, shape2=2)
    } else {
      dist(input$n)
    }# draw n samples
  })
  
  # Reactive expression to update the list of means when the distribution changes
  doReset <- reactive({
    dist <- switch(input$dist,
                   norm = rnorm,
                   unif = runif,
                   beta = rbeta,
                   exp = rexp,
                   rnorm)
    
    # in addition to input$dist react to changes in...
    input$n
    
    means<<-NULL
    print("reset")
  })
  
  # Generate a plot of the data. Also uses the inputs to build
  # the plot label. Note that the dependencies on both the inputs
  # and the data reactive expression are both tracked, and
  # all expressions are called in the sequence implied by the
  # dependency graph
  output$SampDistplot <- renderPlot({
    # Plot parameters...
    tcol="blue"      # fill colors
    acol="light blue"   # color for added samples
    tscale=2;          # label rescaling factor
    
    dist <- input$dist
    n <- input$n
    reps <- 10000
    x<-data()
    doReset()
    
    # Add to list of sample means or repeat sampling reps times depending on checkbox
    means<<-1:reps
    for (i in 1:reps) {
      means[i] <<-mean(switch(dist,
                              norm = rnorm(n),
                              unif = runif(n),
                              beta = rbeta(n = n, shape1 = 5, shape2 = 2),
                              gamma = rgamma(n, shape=2, rate=2),
                              rnorm(n)))
    }
    
    # set plot range
    xmin = switch(dist, norm = -3, unif = 0, beta = 0, gamma = 0, -3)
    xmax = switch(dist, norm =  3, unif = 1, beta = 1, gamma = 5,  3)
    
    # do not plot outliers
    xrm<-x
    xrm[x>xmax]<-NA
    xrm[x<xmin]<-NA
    means[means>xmax]<<-NA
    means[means<xmin]<<-NA
    
    par(mfrow=c(3,1),mar=c(8,6,2,2)) 
    
    # plot true distribution
    x0 = seq(xmin,xmax,length.out=512);
    y0 = switch(dist,
                norm = dnorm(x0),
                unif = dunif(x0),
                beta = dbeta(x0, shape1 = 5, shape2 = 2),
                gamma = dgamma(x0, shape=2, rate=2),
                dnorm(x0))
    y0=y0/sum(y0);
    plot(x0,y0,type="l",lwd=0,col=NULL,main="Population Density",xlab="",ylab="",
         frame=F,cex.lab=tscale, cex.axis=tscale, cex.main=tscale, cex.sub=tscale, yaxt="n") 
    #polygon(c(xmin,x0,xmax),c(0,y0,0),col=tcol,border=tcol,density=0,lwd=2)
    lines(x0,y0,col=tcol,lwd=2)
    
    
    # plot typical sample
    hist(xrm,
         breaks=seq(xmin, xmax, length.out=25),
         main="One Sample from Population",
         warn.unused = FALSE,
         col=tcol,
         border=tcol,
         xlab="",
         cex.lab=tscale,
         cex.axis=tscale,
         cex.main=tscale,
         cex.sub=tscale, yaxt="n", ylab="")
    if (any(x<xmin)) {
      points(rep(xmin-0.1,sum(x<xmin)),rbeta(sum(x<xmin),2,2),lwd=2,col=tcol,cex=tscale)
    }
    if (any(x>xmax)) {
      points(rep(xmax+0.1,sum(x>xmax)),rbeta(sum(x>xmax),2,2),lwd=2,col=tcol,cex=tscale)
    }
    
    # plot list of sample means with the latest sample highlighted and N(mu,sigma^2/n)
    breaks_mh=seq(xmin,xmax,length.out=100);
    y0 = dnorm(x0,switch(dist,
                         norm = 0,
                         unif = 0.5,
                         beta = 5/(5+2),
                         gamma = 1,
                         0),
               switch(dist,
                      norm = 1/sqrt(n),
                      unif = 1/sqrt(12)/sqrt(n),
                      beta = (5*2)/((5+2)^2*(5+2+1)),
                      exp = 1/sqrt(n),
                      0))
    y0=y0/sum(y0)*length(means)*mean(diff(breaks_mh))/mean(diff(x0))
    
    nh<-hist(means,
             breaks=breaks_mh,
             main="Sampling Distribution of x-bar",
             warn.unused = FALSE,
             col=tcol,
             border=tcol,
             xlab="",
             cex.lab=tscale,
             cex.axis=tscale,
             cex.main=tscale,
             cex.sub=tscale, yaxt="n",
             ylab="")
    if (mean(x)>xmin && mean(x)<xmax) {
      hist(mean(x),
           breaks=breaks_mh,
           col=tcol,
           border=tcol,
           add=TRUE,
           ylim=c(0,max(y0,max(nh$counts))))
    }
    #points(x0,y0,type="l",lwd=2)
    #print(input$resample)
  },height=800)
  
  # Generate a summary of the data
  output$summary <- renderPrint({
    summary(data())
  })
  
  # Generate an HTML table view of the data
  output$table <- renderTable({
    data.frame(x=data())
  })
  
  
  
} #End Server DON'T DELETE THIS CURLY BRACE

