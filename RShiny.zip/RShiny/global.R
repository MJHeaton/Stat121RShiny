##
## Files available globally to both ui and server functions
##

## Global Libraries
library(shinydashboard)
library(shiny)
library(shinyjs)
library(shinyWidgets)
library(ggplot2)
library(tidyverse)
library(shinydashboardPlus)
library(MASS)
library(datasets)
library(BSDA)
library(gridExtra)
library(DescTools)

# List of Datasets and Descriptions ---------------------------------------
list.of.data.names <- c("MPG","Windmill","Distracted Driving","Masters Degree", "Crabs", "Plant Growth",
                        "Graduate Admission For Indian Students", "NBA Players from 1976-2016", "CPI", "Track",
                        "Student Survey", "Migraine", "Broadway", "Bone Loss","401K Returns",
                        "Chlorine", "Tipping", "Chick-fil-A", "Career Networking", "Delta Flights",
                        "Website Designs", "Inmate Stress", "Fertilizer Experiment", "ED Wait Times", "2018 Student Survey")

list.of.data.files <- c("MPG.txt","Windmill.txt","DistractedDriving.csv",
                        "MastersDegree.txt", "Crabs.txt", "Plants.txt", "Admission_Predict.csv", "NBA.csv",
                        "world_cpi.csv", "Track.csv", "CleanedFall2021.csv", "migraines.csv", "Broadway.csv",
                        "BoneLoss.txt", "Returns.csv", "Chlorine.txt", "Tipping.txt", "ChickFilA.txt",
                        "Networking.txt", "FlightDelays.csv", "WebsiteDesign.txt", "InmateStress.txt",
                        "cropdata.csv", "HospitalWaitTimes.csv", "StudentResponses2018.csv")

list.of.data.seps <- c(" ", " ", ",", " ", " ", " ", ",", ",", ",", ",", ",", ",", ",", " ",
                       ",", " ", " ", " ", " ", ",", " ", " ", ",", ",", ",")
list.of.data.seps <- list.of.data.seps[order(list.of.data.names)]
list.of.data.files <- list.of.data.files[order(list.of.data.names)]
list.of.data.names <- sort(list.of.data.names)
data.desc <- vector("list",length=length(list.of.data.files))

data.desc[[which(list.of.data.names=="MPG")]] <- paste("This dataset consists of measurements of car weights compared",
                                                       "to car MPG.  The goal of analyzing this data is to, first, understand the relationship between weight and MPG",
                                                       "and, second, to use a car's weight to predict the MPG.")

data.desc[[which(list.of.data.names=="Windmill")]] <- paste("This dataset consists of measurements of the windspeed at a",
                                                            "candidate site for a wind farm and a nearby reference site.  The goal of collecting this data is to see if the",
                                                            "reference site windspeed can be used to predict the candidate site speed.")

data.desc[[which(list.of.data.names=="Distracted Driving")]] <- paste("This dataset consists of information on fatal crashes in the US as categorized",
                                                                      "by age of the driver and if the driver was distracted.  The goal of collecting",
                                                                      "this data is to determine if there is a relationship between age and if the driver",
                                                                      "was distracted before the crash occurred.")

data.desc[[which(list.of.data.names=="Masters Degree")]] <- paste("This dataset compares the percent of women and men who are considering",
                                                                  "pursuing a MS degree in Statistics.  The goal of collecting",
                                                                  "this data is to determine if more men than women are considering graduate",
                                                                  "school.")

data.desc[[which(list.of.data.names=="Crabs")]] <- paste("This dataset consists of measurements describing 5 morphological measurements on",
                                                         "50 crabs, each of two colour forms and both sexes. ")

data.desc[[which(list.of.data.names=="Plant Growth")]] <- paste("Results from an experiment to compare yields (as measured by dried weight of",
                                                                "plants) obtained under a control and two different treatment conditions.")

data.desc[[which(list.of.data.names=="Graduate Admission For Indian Students")]] <- paste("The dataset contains several parameters which are considered important during the application for Masters Programs.",
                                                                                          "The parameters included are : 1. GRE Scores (out of 340) 2. TOEFL Scores (out of 120) 3. University Rating (out of 5)",
                                                                                          "4. Statement of Purpose and Letter of Recommendation Strength (out of 5) 5. Undergraduate GPA (out of 10)",
                                                                                          "6. Research Experience (either 0 or 1) 7. Chance of Admit (ranging from 0 to 1)")

data.desc[[which(list.of.data.names=="NBA Players from 1976-2016")]] <- paste("This dataset is comprised of various statistics such as age, PER (player efficiency rating)",
                                                                              "G (games played), height and weight. For a full description of these statistics and what they",
                                                                              "mean or how they are calculated, refer to www.basketball-reference.com")

data.desc[[which(list.of.data.names=="CPI")]] <- paste("CPI stands for City Prosperity Index. In this data set you have a 5 dimensional index (which uses",
                                                       "all of the given indices), a 4 dimensional index, and all of the individual dimension variables.")

data.desc[[which(list.of.data.names=="Track")]] <- paste("This dataset contains the 3178 fastest Men's 100 meters sprint times in the world.",
                                                         "Variables include the time ranking, sprint time, wind speed, first name, last name, and the city where the race was competed.",
                                                         "Positive wind values indicate the wind was blowing behind the competitor and made them run faster,",
                                                         "while negative wind values indicate running into the wind which causes slower times.",
                                                         "Times with wind values greater than 2.0 m/s are not viable for setting records per the IAAF.")

data.desc[[which(list.of.data.names=="Student Survey")]] <- paste("Responses from the survey given at the beginning of the course.")

data.desc[[which(list.of.data.names=="Migraine")]] <- paste("Data from the migraine matched pairs study.")

data.desc[[which(list.of.data.names=="Broadway")]] <- paste("This data set contains information about 95 plays, musicals, and musical revues that ran during the 1997 - 1998 Broadway season.")

data.desc[[which(list.of.data.names=="Bone Loss")]] <- paste("Data on percent bone density loss among breastfeeding mothers.")

data.desc[[which(list.of.data.names=="401K Returns")]] <- paste("Data on the annual return of a 401K portfolio.")

data.desc[[which(list.of.data.names=="Chlorine")]] <- paste("Data on the chlorine content (in ppm) in a pool.")

data.desc[[which(list.of.data.names=="Tipping")]] <- paste("Data on tipping on a rainy day (in percent of bill total).")

data.desc[[which(list.of.data.names=="Chick-fil-A")]] <- paste("Data on the accuracy of orders from Chick-fil-A.")

data.desc[[which(list.of.data.names=="Career Networking")]] <- paste("Data on the percent of workers who obtained their job via career networking.")

data.desc[[which(list.of.data.names=="Delta Flights")]] <- paste("Data on Delta Airline's flight delays between SLC and ATL.")

data.desc[[which(list.of.data.names=="Website Designs")]] <- paste("Data on amount spent per visitor with two different website designs.")

data.desc[[which(list.of.data.names=="Inmate Stress")]] <- paste("Data on stress levels of penitentiary inmates based on living conditions.")

data.desc[[which(list.of.data.names=="Fertilizer Experiment")]] <- paste("Data from an experiment comparing 3 fertilizers.")

data.desc[[which(list.of.data.names=="ED Wait Times")]] <- paste("Wait times to see a physician in an emergency room in Canada.")

data.desc[[which(list.of.data.names=="2018 Student Survey")]] <- paste("Responses from a BYU Student Survey in 2018.")



## Functions I use
getNumMode <- function(num){
  num.dens <- density(num)
  round(num.dens$x[which.max(num.dens$y)],2)
}
